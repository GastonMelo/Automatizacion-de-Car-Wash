package com.example.car_wash_app;


import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.car_wash_app.PrefConfig.UserIDXML;


/**
 * A simple {@link Fragment} subclass.
 */
public class LoginFragment extends Fragment {

    private TextView RegText;
    private EditText DNI,Clave;
    private Button LoginBtn;

    OnLoginFormActivityListener loginFormActivityListener;

    public interface OnLoginFormActivityListener
    {
        public void performRegister();
        public void performLogin(String name);
    }
    public LoginFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_login, container, false);
        ((MainActivity)getActivity()).getSupportActionBar().setTitle("Login");
        ((MainActivity)getActivity()).getSupportActionBar().setDisplayShowHomeEnabled(true);
        ((MainActivity)getActivity()).getSupportActionBar().setIcon(R.drawable.iconoapp);
        RegText = view.findViewById(R.id.registrarse_txt);
        DNI = view.findViewById(R.id.dni);
        Clave = view.findViewById(R.id.clave);
        LoginBtn = view.findViewById(R.id.btn_login);
        LoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                performLogin();
            }
        });

        RegText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginFormActivityListener.performRegister();
            }
        });
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        Activity activity = (Activity) context;
        loginFormActivityListener = (OnLoginFormActivityListener) activity;
    }
    /********************************************************************************/
    /*                      LOGIN DE USUARIO                                        */
    /********************************************************************************/
    private void performLogin()
    {
        final String dni = DNI.getText().toString();
        String clave = Clave.getText().toString();
        Call<User> call = MainActivity.apiInterface.performUserLogin(dni,clave);
        call.enqueue(new Callback<User>()
        {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    MainActivity.prefConfig.WriteLoginStatus(true);
                    MainActivity.prefConfig.Write(UserIDXML,dni);
                    loginFormActivityListener.performLogin(response.body().getName());
                }
                else if(response.body().getResponse().contains("failed"))
                {
                    MainActivity.prefConfig.DisplayToast("Login Failed...try again");
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                Log.w("MyTag", "requestFailed", t);
            }
        });
        DNI.setText("");
        Clave.setText("");
    }
}
