package com.example.car_wash_app;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

public class PrefConfig
{
    /********************************************************************************/
    /*                DEFINICION VARIABLES GLOBALES ESCRITURA Y LECTURA             */
    /********************************************************************************/
    public static String NameStringXML = "com.example.preference_user_name";
    public static String UserIDXML = "com.example.preference_user_id";
    public static String UserToken = "com.example.preference_user_token";
    public static String ValorFicha = "com.example.preference_valorficha";
    public static String Payerlastname = "com.example.preference_user_lastname";
    public static String Payer_Email = "com.example.preference_user_email";
    /********************************************************************************/
    /*                          FIN DEFINICIONES                                    */
    /********************************************************************************/
    private SharedPreferences sharedPreferences;
    private Context context;

    public PrefConfig(Context context)
    {
        this.context = context;
        sharedPreferences = context.getSharedPreferences(context.getString(R.string.pref_file),Context.MODE_PRIVATE);

    }


    public void WriteLoginStatus(boolean status)
    {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(context.getString(R.string.pref_login_status),status);
        editor.commit();
    }


    public  boolean ReadLoginStatus()
    {
        return sharedPreferences.getBoolean(context.getString(R.string.pref_login_status), false);
    }

    public String Read(String stringxml)
    {
        return sharedPreferences.getString(stringxml, "User");
    }

    public void Write(String stringxml,String value)
    {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(stringxml, value);
        editor.commit();
    }

    public void DisplayToast(String message)
    {
        Toast.makeText(context,message,Toast.LENGTH_SHORT).show();
    }

}
