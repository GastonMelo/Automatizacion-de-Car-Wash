package com.example.car_wash_app;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

import static com.example.car_wash_app.PrefConfig.NameStringXML;
import static com.example.car_wash_app.PrefConfig.UserIDXML;
import static com.example.car_wash_app.PrefConfig.UserToken;


public class MainActivity extends AppCompatActivity implements LoginFragment.OnLoginFormActivityListener, WelcomeFragment.OnLogoutListener, ForceUpdateChecker.OnUpdateNeededListener{

    public static PrefConfig prefConfig;
    public static ApiInterface apiInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Login");
        /********************************************************************************/
        /*                       CHECK FOR UPDATES                                      */
        /********************************************************************************/
        ForceUpdateChecker.with(this).onUpdateNeeded(this).check();
        /********************************************************************************/
        /*                      FIRECLOUD MESSAGES                                      */
        /********************************************************************************/
       FirebaseInstanceId.getInstance()
                .getInstanceId().addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                    @Override
                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
                        if(task.isSuccessful())
                        {
                            String token = task.getResult().getToken();
                            prefConfig.Write(UserToken,token);
                        }
                        else
                        {

                        }
                    }
                });
        /********************************************************************************/
        /*                      FIRECLOUD MESSAGES                                      */
        /********************************************************************************/
        prefConfig = new PrefConfig(this);
        apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        if(findViewById(R.id.fragment_container) != null)
        {
            if(savedInstanceState != null)
            {
                return;
            }
            if(prefConfig.ReadLoginStatus())
            {
                getSupportFragmentManager().beginTransaction().add(R.id.fragment_container,new WelcomeFragment()).commit();
            }
            else
            {
                getSupportFragmentManager().beginTransaction().add(R.id.fragment_container,new LoginFragment()).commit();
            }
        }
        //String token = prefConfig.Read(UserToken);
        //prefConfig.DisplayToast(token);
    }
    /********************************************************************************/
    /*                      REALIZA REGISTRO USUARIO                                */
    /********************************************************************************/
    @Override
    public void performRegister() {
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new RegistrationFragment()).addToBackStack(null).commit();
    }
    /********************************************************************************/
    /*                      REALIZA LOGIN USUARIO                                   */
    /********************************************************************************/
    @Override
    public void performLogin(String name)
    {
        prefConfig.Write(NameStringXML,name);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new WelcomeFragment()).commit();
    }
    /********************************************************************************/
    /*                      REALIZA LOGOUT USUARIO                                  */
    /********************************************************************************/
    @Override
    public void logoutperformed() {
        prefConfig.WriteLoginStatus(false);
        prefConfig.Write(NameStringXML,"User");
        prefConfig.Write(UserIDXML,"User");
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new LoginFragment()).commit();
    }

    @Override
    public void onUpdateNeeded(String updateUrl) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Nueva version disponible")
                .setMessage("Porfavor actualice la aplicación antes de continuar")
                .setPositiveButton("Update",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //redirectStore(updateUrl);
                            }
                        }).setNegativeButton("No, gracias",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        }).create();
        dialog.show();
    }
    private void redirectStore(String updateUrl) {
        final Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(updateUrl));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}
