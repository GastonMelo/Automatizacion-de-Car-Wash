package com.example.car_wash_app;


import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.journeyapps.barcodescanner.BarcodeEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.EnumMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.car_wash_app.PrefConfig.NameStringXML;
import static com.example.car_wash_app.PrefConfig.UserIDXML;
import static com.example.car_wash_app.PrefConfig.UserToken;


/**
 * A simple {@link Fragment} subclass.
 */
public class WelcomeFragment extends Fragment implements dialog_qr.QrDialogListenner{

    private Button btncredit,facebook,whatsapp,instagram;
    public String FuncionQr,ValorFichaActual = "0",clientcredit = "0";
    OnLogoutListener logoutListener;
    static MenuItem ficha_value, credito_cliente;

    public static WelcomeFragment instance = null;

    public interface OnLogoutListener
    {
        public void logoutperformed();
    }
    public WelcomeFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;
    }

    public static  WelcomeFragment getInstance() {
        return instance;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        /********************************************************************************/
        /*                      UPGRADE VALUES FROM DATABASE                            */
        /********************************************************************************/
        ValorFichaActual();
        performReadCredit();
        SendToken();
        /********************************************************************************/
        /*                                                                              */
        /********************************************************************************/
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_welcome, container, false);
        ImageView DNIQR = view.findViewById(R.id.DNIQR);
        String DNI_QR = MainActivity.prefConfig.Read(UserIDXML);
        MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
        try{
            Map<EncodeHintType, Object> hintMap = new EnumMap<EncodeHintType, Object>(EncodeHintType.class);
            hintMap.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            hintMap.put(EncodeHintType.MARGIN, 1);
            hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
            BitMatrix bitMatrix = multiFormatWriter.encode(DNI_QR, BarcodeFormat.QR_CODE,200,200,hintMap);
            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);
            DNIQR.setImageBitmap(bitmap);
        }catch (WriterException e){

        }
        setHasOptionsMenu(true);
        ((MainActivity)getActivity()).getSupportActionBar().setTitle(MainActivity.prefConfig.Read(NameStringXML));
        facebook = view.findViewById(R.id.Facebook);
        whatsapp = view.findViewById(R.id.Whatsapp);
        instagram = view.findViewById(R.id.Instagram);
        btncredit = view.findViewById(R.id.btn_credito);
        btncredit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                IntentIntegrator vistaescanner = IntentIntegrator.forSupportFragment(WelcomeFragment.this);
                vistaescanner.setPrompt("Scan");
                vistaescanner.setBeepEnabled(true);
                vistaescanner.setOrientationLocked(true);
                vistaescanner.initiateScan();
            }
        });
        facebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotofacebook("197623960369434");
            }
        });
        whatsapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotowhatsapp();
            }
        });
        instagram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoinstagram();
            }
        });
        return view;
    }

    private void gotoinstagram()
    {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://instagram.com/_u/007CARWASH/"));
            startActivity(intent);
        }catch (ActivityNotFoundException e){
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/USER/007CARWASH"));
            startActivity(intent);
        }
    }

    private void gotowhatsapp()
    {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=+5492994065854"));
            startActivity(intent);
        }catch (ActivityNotFoundException e){
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/"));
            startActivity(intent);
        }
    }

    private void gotofacebook(String id)
    {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("fb://page/" + id));
            startActivity(intent);
        }catch (ActivityNotFoundException e){
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/"));
            startActivity(intent);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        Activity activity = (Activity) context;
        logoutListener = (OnLogoutListener) activity;
    }
    /********************************************************************************/
    /*                      INCLUYE MENU USUARIO EN TASKBAR                         */
    /********************************************************************************/

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflator) {
        inflator.inflate(R.menu.menu_main, menu);
        ficha_value = menu.findItem(R.id.ficha_valor);
        credito_cliente = menu.findItem(R.id.creditocliente);
        ficha_value.setTitle("$" + ValorFichaActual);
        credito_cliente.setTitle("$" + clientcredit);
        return;
    }
    /********************************************************************************/
    /*                      FIRECLOUD MESSAGES                                      */
    /********************************************************************************/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.Mercadopago)
        {
            Intent intent = new Intent(getActivity(), MercadoPago.class);
            intent.putExtra("valor_ficha", ValorFichaActual);
            startActivity(intent);
        }
        if(item.getItemId() == R.id.Logout)
        {
            logoutListener.logoutperformed();
        }
        if(item.getItemId() == R.id.About)
        {
            Intent intent = new Intent(getActivity(),about_me.class);
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }
    /********************************************************************************/
    /*                      QR scan resultado                                       */
    /********************************************************************************/
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        IntentResult scan_result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if(scan_result.getContents() != null)
        {
            FuncionQr = scan_result.getContents();
            dialog_qr();
        }
    }

    @Override
    public void OnClickOK() {
        performOperation();
    }
    /**
     * Called if InstanceID token is updated. This may occur if the security of
     * the previous token had been compromised. Note that this is called when the InstanceID token
     * is initially generated so this is where you would retrieve the token.
     */
    /********************************************************************************/
    /*                      ACTUALIZA VALOR DE TOKEN                                */
    /********************************************************************************/
    public void SendToken()
    {
        String dni = MainActivity.prefConfig.Read(UserIDXML);
        String Token = MainActivity.prefConfig.Read(UserToken);
        Call<User> call = MainActivity.apiInterface.SendToken(dni,Token);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response)
            {
                if(response.body().getResponse().equals("ok"))
                {
                    //MainActivity.prefConfig.DisplayToast("token registrado");
                }
            }
            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }
    /********************************************************************************/
    /*                      ACTUALIZA VALOR DE FICHA                                */
    /********************************************************************************/
    public void ValorFichaActual()
    {
        Call<User> call = MainActivity.apiInterface.ValorFichaActual();
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response)
            {
                if(response.body().getResponse().equals("ok"))
                {
                    String valoractual = response.body().getValorFicha().toString();
                    ValorFichaActual = valoractual;
                    getActivity().invalidateOptionsMenu();
                }
                else
                {
                    dialog_error();
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }
    /********************************************************************************/
    /********************************************************************************/
    /*                      LECTURA DE CREDITO EN BASE DATOS                        */
    /********************************************************************************/
    public void performReadCredit()
    {

        String dni = MainActivity.prefConfig.Read(UserIDXML);
        Call<User> call = MainActivity.apiInterface.performReadCredit(dni);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    clientcredit = response.body().getCredito();
                    getActivity().invalidateOptionsMenu();
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }
    /********************************************************************************/
    /*                      ACTIVA HIDRO O ASPIRADORA                               */
    /********************************************************************************/
    public void performOperation()
    {
        String dni = MainActivity.prefConfig.Read(UserIDXML);
        Date now = new Date();
        String fecha = new SimpleDateFormat("yyyy-MM-dd").format(now);
        String valor_ficha = ValorFichaActual;
        Call<User> call = MainActivity.apiInterface.performOperation(dni,valor_ficha,fecha);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    performReadCredit();
                    habilitarGpio(FuncionQr);
                }
                else
                {
                    dialog_error();
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }

    /********************************************************************************/
    /*                      ACTIVA GPIOS DE RASPBERRY                               */
    /********************************************************************************/
    public void habilitarGpio(String Funcion_usando)
    {
        String gpio = "0";

        switch (Funcion_usando)
        {
            case "hidrolavadora_1":
                    gpio = "0";
                    break;

            case "hidrolavadora_2":
                    gpio = "1";
                    break;

            case "hidrolavadora_3":
                    gpio = "2";
                    break;

            case "hidrolavadora_4":
                    gpio = "3";
                    break;

            case "aspiradora_1":
                    gpio = "4";
                    break;
            case "aspiradora_2":
                    gpio = "5";
                    break;

            case "aspiradora_3":
                    gpio = "6";
                    break;

             case "aspiradora_4":
                    gpio = "7";
                    break;
        }
        Call<User> call = MainActivity.apiInterface.activategpio(gpio);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {

                }
                else
                {
                    dialog_error();
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });

    }
    private void dialog_qr()
    {
        dialog_qr dialog_qr = new dialog_qr();
        dialog_qr.setTargetFragment(WelcomeFragment.this, 1);
        dialog_qr.setCancelable(false);
        dialog_qr.show(getFragmentManager(),null);
    }
    private void dialog_error()
    {
        dialog_error dialog_error = new dialog_error();
        dialog_error.setTargetFragment(WelcomeFragment.this, 1);
        dialog_error.setCancelable(false);
        dialog_error.show(getFragmentManager(),null);
    }
}
