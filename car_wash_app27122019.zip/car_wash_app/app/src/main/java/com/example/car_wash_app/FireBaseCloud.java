package com.example.car_wash_app;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import org.json.JSONException;
import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.support.constraint.Constraints.TAG;
import static com.example.car_wash_app.PrefConfig.UserIDXML;
import static com.example.car_wash_app.PrefConfig.UserToken;

public class FireBaseCloud extends FirebaseMessagingService {
    public FireBaseCloud()
    {

    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        // ...

        // TODO(developer): Handle FCM messages here.
        // Not getting messages here? See why this may be: https://goo.gl/39bRNJ
        Log.d(TAG, "From: " + remoteMessage.getFrom());

        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
            try {
                Log.d(TAG, "Message data payload: " + remoteMessage.getData());
                JSONObject data = new JSONObject(remoteMessage.getData());
                String jsonMessage = data.getString("message");
                Log.d(TAG, "Message received" + jsonMessage);
            }catch (JSONException e){
                e.printStackTrace();
            }
            if (/* Check if data needs to be processed by long running job */ true) {
                // For long-running tasks (10 seconds or more) use Firebase Job Dispatcher.
                //scheduleJob();
            } else {
                // Handle message within 10 seconds
                //handleNow();
            }

        }
        String LauncherActivity = "default";
        String Data = null;
        String title =  remoteMessage.getData().get("title");
        String message = remoteMessage.getData().get("body");
        String extra = remoteMessage.getData().get("extra");

        if(extra != null) {
            String[] split = extra.split("_");
            LauncherActivity = split[0];
            Data = split[1];
        }
        Log.d(TAG, "Message Notification Body: " + title);
        Log.d(TAG, "Message Notification Body: " + message);
        Log.d(TAG, "Message Notification Body: " + extra);
        sendNotification(title,message, LauncherActivity, Data);
        // Also if you intend on generating your own notifications as a result of a received FCM
        // message, here is where that should be initiated. See sendNotification method below.
    }

    private void sendNotification(String title, String message, String LauncherActivity, String Data)
    {
        PendingIntent notifypendingIntent = null ;
        Intent intent = null;
        switch(LauncherActivity)
        {
            case "CargaCredito":
            {
                WelcomeFragment.instance.performReadCredit();
                intent = new Intent(this, Carga_Credito.class);
                intent.putExtra("Extra",Data);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                break;
            }
            case "Descuento":
            {
                intent = new Intent(this, Descuento.class);
                intent.putExtra("Extra",Data);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                break;
            }
            case "Promocion":
            {
                intent = new Intent(this, promociones.class);
                intent.putExtra("Titulo", title);
                intent.putExtra("Mensaje",message);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                break;
            }
            case "UpdateFicha":
            {
                WelcomeFragment.instance.ValorFichaActual();
                intent = new Intent(this, UpdateValorFicha.class);
                intent.putExtra("UpdateFichavalue", Data);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                break;
            }
            default:
            {
                intent = new Intent(this, MainActivity.class);
                intent.putExtra("Extra",Data);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            }

        }
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        notifypendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT);//
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        String NOTIFICATION_CHANNEL_ID = "promocion_carwash";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "My Notifications", NotificationManager.IMPORTANCE_HIGH);
            //@SuppressLint("WrongConstant")  Configure the notification channel.
            notificationChannel.setDescription("Sample Channel description");
            notificationChannel.enableLights(true);
            notificationChannel.setVibrationPattern(new long[]{0, 1000, 500, 1000});
            notificationChannel.enableVibration(true);
            notificationManager.createNotificationChannel(notificationChannel);
        }
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID);
        notificationBuilder.setAutoCancel(true)
                .setDefaults(Notification.DEFAULT_ALL)
                .setWhen(System.currentTimeMillis())
                .setSmallIcon(R.drawable.ic_myappicon)
                .setContentTitle(title)
                .setContentText(message)
                .setContentIntent(notifypendingIntent)
                .setContentInfo("Car Wash");
        notificationManager.notify(1, notificationBuilder.build());
    }

    @Override
    public void onNewToken(String token) {
        //Log.d(TAG, "Refreshed token: " + token);
        //SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(getString(R.string.pref_FCM), Context.MODE_PRIVATE);
        //MainActivity.prefConfig.DisplayToast(task.getResult().getToken());
        //token.toString();
        MainActivity.prefConfig.Write(UserToken,token);
        Call<User> call = MainActivity.apiInterface.SendToken(UserIDXML,token);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response)
            {
                if(response.body().getResponse().equals("ok"))
                {
                    //MainActivity.prefConfig.DisplayToast("token registrado");
                }

            }
            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
        // If you want to send messages to this application instance or
        // manage this apps subscriptions on the server side, send the
        // Instance ID token to your app server.
        //sendRegistrationToServer(token);
    }

}
