package com.example.car_wash_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class UpdateValorFicha extends AppCompatActivity {
    private Button Continuar;
    private TextView NuevoValorFicha;
    public String msg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_valor_ficha);
        msg = getIntent().getStringExtra("UpdateFichavalue");
        NuevoValorFicha = findViewById(R.id.update_valor_ficha);
        NuevoValorFicha.setText("Valor de ficha : " + msg);
        Continuar = findViewById(R.id.Continuar);
        Continuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                Intent intent = new Intent(UpdateValorFicha.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
