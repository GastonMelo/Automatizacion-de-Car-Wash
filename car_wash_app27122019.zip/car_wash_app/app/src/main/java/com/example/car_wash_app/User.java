package com.example.car_wash_app;

import com.google.gson.annotations.SerializedName;

public class User
{

    @SerializedName("response")
    private String Response;

    @SerializedName("nombre")
    private String Name;

    @SerializedName("credito")
    private String Credito;

    @SerializedName("valor_ficha")
    private String ValorFicha;

    public String getValorFicha() {
        return ValorFicha;
    }

    public String getCredito() {
        return Credito;
    }

    public String getResponse() {
        return Response;
    }

    public String getName() {
        return Name;
    }
}
