package com.example.car_wash_app;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.mercadopago.android.px.core.MercadoPagoCheckout;

import com.mercadopago.android.px.model.Payment;
import com.mercadopago.android.px.model.exceptions.MercadoPagoError;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;

import static com.example.car_wash_app.PrefConfig.NameStringXML;
import static com.example.car_wash_app.PrefConfig.Payer_Email;
import static com.example.car_wash_app.PrefConfig.Payerlastname;
import static com.example.car_wash_app.PrefConfig.UserIDXML;
import static com.google.zxing.integration.android.IntentIntegrator.REQUEST_CODE;

public class MercadoPago extends AppCompatActivity {
    EditText ImporteMercadopago,PayerName,PayerLastName,PayerDNI,PayerEmail;
    Button MercadopagoPagar;
    public String ValorFicha;

    public static final String PUBLIC_KEY="TEST-768d220a-56f1-4e38-b44a-ceb60ac34c1f";
    public static final String ACCESS_TOKEN_SANDBOX = "TEST-8905384523291825-120611-002f9fb3560b3757cc880349e90ac5b4-114482627";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setTitle("Mercadopago checkout");
        setContentView(R.layout.activity_mercado_pago);
        ImporteMercadopago = findViewById(R.id.ImporteMercadopago);
        PayerName = findViewById(R.id.PayerName);
        PayerLastName = findViewById(R.id.PayerLastName);
        PayerDNI = findViewById(R.id.PayerDni);
        PayerEmail = findViewById(R.id.PayerEmail);
        MercadopagoPagar = findViewById(R.id.MercadopagPagar);
        ValorFicha = getIntent().getStringExtra("valor_ficha");
/******************************************************************************************/
/*                   fill text with data already store in phone                           */
/******************************************************************************************/
        PayerName.setText(MainActivity.prefConfig.Read(NameStringXML));
        PayerLastName.setText(MainActivity.prefConfig.Read(Payerlastname));
        PayerDNI.setText(MainActivity.prefConfig.Read(UserIDXML));
        PayerEmail.setText(MainActivity.prefConfig.Read(Payer_Email));
/******************************************************************************************/
/******************************************************************************************/
        MercadopagoPagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pagar_importe_mercadopago();
            }
        });
    }
    private void pagar_importe_mercadopago()
    {
        JSONObject jsonObject = new JSONObject();
        final JSONObject itemJSON = new JSONObject();
        final JSONObject payerJSON = new JSONObject();
        JSONArray itemJsonArray = new JSONArray();
        try {

            itemJSON.put("title", "Lavadero");
            itemJSON.put("description", "Valor de Ficha");
            itemJSON.put("quantity", 1);
            itemJSON.put("currency_id", "ARS");
            String data = ImporteMercadopago.getText().toString();
            itemJSON.put("unit_price",Integer.parseInt(ImporteMercadopago.getText().toString()));//

            itemJsonArray.put(itemJSON);

            //JSONObject phoneJSON = new JSONObject();
            //phoneJSON.put("area_code", PayerArea.getText().toString());//
            //phoneJSON.put("number", PayerPhone.getText().toString());//
            JSONObject idJSON = new JSONObject();
            idJSON.put("type", "DNI");
            idJSON.put("number", PayerDNI.getText().toString());//
            JSONObject addressJSON = new JSONObject();
            addressJSON.put("street_name", "San Martin");
            addressJSON.put("street_number", 4250);
            addressJSON.put("zip_code", "8300");

            payerJSON.put("name", PayerName.getText().toString());//
            payerJSON.put("surname", PayerLastName.getText().toString());//
            payerJSON.put("email", PayerEmail.getText().toString());//
            Date now = new Date();
            String fecha = new SimpleDateFormat("yyyy-MM-dd").format(now);
            payerJSON.put("date_created", fecha);
            //payerJSON.put("phone", phoneJSON);
            payerJSON.put("identification", idJSON);
            payerJSON.put("address", addressJSON);


            jsonObject.put("items", itemJsonArray);
            jsonObject.put("payer", payerJSON);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestQueue requestQueue = Volley.newRequestQueue(MercadoPago.this);
        final String url = "https://api.mercadopago.com/checkout/preferences?access_token="+ACCESS_TOKEN_SANDBOX;
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, jsonObject, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    Log.i("debinf MainAct", "response JSONObject: "+response);
                    String checkoutPreferenceId = response.getString("id");
                    new MercadoPagoCheckout.Builder(PUBLIC_KEY, checkoutPreferenceId).build().startPayment(MercadoPago.this,REQUEST_CODE);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i("debinf MainAct", "response ERROR: "+error.networkResponse.allHeaders);
            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                return headers;
            }
        };
        requestQueue.add(jsonObjectRequest);
    }
    /********************************************************************************/
    /*                      cargasrcreditocliente-->MERCADOPAGO--->                 */
    /********************************************************************************/
    private void cargarcreditocliente(final String dnicliente, final String importe)
    {
        Date now = new Date();
        String vendedor = "MercadoPago";
        String fecha = new SimpleDateFormat("yyyy-MM-dd").format(now);
        Call<User> call = MainActivity.apiInterface.performChargeCredit(dnicliente,importe,fecha,vendedor);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, retrofit2.Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    notificar_resultado_cliente();
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }
    /*********************************************************************************/
    /*********************************************************************************/
    private void notificar_resultado_cliente()
    {
        Intent intent = new Intent(this, Carga_Credito.class);
        intent.putExtra("message", ImporteMercadopago.getText().toString());
        startActivity(intent);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == REQUEST_CODE) {
            if (resultCode == MercadoPagoCheckout.PAYMENT_RESULT_CODE) {
                final Payment payment = (Payment) data.getSerializableExtra(MercadoPagoCheckout.EXTRA_PAYMENT_RESULT);
                //((TextView) findViewById(R.id.mp_results)).setText("Resultado del pago: " + payment.getStatus());
                    cargarcreditocliente(PayerDNI.getText().toString(),ImporteMercadopago.getText().toString());
                //Done!
            } else if (resultCode == RESULT_CANCELED) {
                if (data != null && data.getExtras() != null
                        && data.getExtras().containsKey(MercadoPagoCheckout.EXTRA_ERROR)) {
                    final MercadoPagoError mercadoPagoError =
                            (MercadoPagoError) data.getSerializableExtra(MercadoPagoCheckout.EXTRA_ERROR);
                    //((TextView) findViewById(R.id.mp_results)).setText("Error: " +  mercadoPagoError.getMessage());
                    //Resolve error in checkout
                } else {
                    //Resolve canceled checkout
                }
            }
        }
    }
}
