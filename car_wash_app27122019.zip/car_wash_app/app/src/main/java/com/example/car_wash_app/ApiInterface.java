package com.example.car_wash_app;


import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ApiInterface
{
    @GET("register.php")
    Call<User> performRegistration(@Query("dni") String DNI,@Query("nombre") String Nombre, @Query("apellido") String Apellido , @Query("fecha_nac") String FechaNac, @Query("genero") String Sexo,@Query("modelo_vehiculo") String ModeloVehiculo,@Query("direccion_correo") String DireccionCorreo, @Query("clave") String Clave,@Query("manufacturer") String Manufacturer,@Query("model") String Model,@Query("version") int Version,@Query("versionRelease") String VRelease,@Query("token") String Token);
    @GET("login.php")
    Call<User> performUserLogin(@Query("dni") String DNI, @Query("clave") String Clave);
    @POST("fcm_insert.php")
    Call<User> SendToken(@Query("dni") String DNI, @Query("fcm_token") String FCMToken);
    @GET("valor_ficha.php")
    Call<User> ValorFichaActual();
    @GET("consumir_ficha.php")
    Call<User> performOperation(@Query("dni") String DNI, @Query("valor_ficha") String ValorFicha,@Query("fecha") String Fecha);
    @GET("ver_saldo.php")
    Call<User> performReadCredit(@Query("dni") String DNI);
    @GET("box_funcion.php")
    Call<User> activategpio(@Query("gpio") String GPIO);
    @GET("cargar_credito.php")
    Call<User> performChargeCredit(@Query("dni") String DNI, @Query("credito") String Credito, @Query("fecha") String Fecha, @Query("vendedor") String Vendedor);

}
