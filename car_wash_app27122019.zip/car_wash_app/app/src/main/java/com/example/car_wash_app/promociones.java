package com.example.car_wash_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class promociones extends AppCompatActivity {
    public String promo_titulo, promo_mensaje;
    private Button Continuar;
    private TextView Titulo, Mensaje;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_promociones);
        getSupportActionBar().setTitle("Promociones");
        Titulo = findViewById(R.id.TituloPromo);
        Mensaje = findViewById(R.id.MensajePromo);
        promo_titulo = getIntent().getStringExtra("Titulo");
        Titulo.setText(promo_titulo.toString());
        promo_mensaje = getIntent().getStringExtra("Mensaje");
        Mensaje.setText(promo_mensaje.toString());
        Continuar = findViewById(R.id.Continuar);
        Continuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                Intent intent = new Intent(promociones.this,MainActivity.class);
                startActivity(intent);
            }
        });

    }
}
