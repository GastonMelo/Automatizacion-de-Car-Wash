package com.example.carwashadmin;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class CustomAdapterButtons extends ArrayAdapter {
    private Context context;
    private Fragment fragment;
    private String[] nombre;
    private String identificador;
    private Button edt;
    private Button del;

    public CustomAdapterButtons(Context context,int resources,String[] nombre,Fragment fragment,String identificador)
    {
        super(context,resources);
        this.fragment = fragment;
        this.context = context;
        this.nombre = nombre;
        this.identificador = identificador;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = LayoutInflater.from((Context) context).inflate(R.layout.listview_buttons, parent, false);
        TextView column1 = view.findViewById(R.id.nombre);
        del = view.findViewById(R.id.del);
        edt = view.findViewById(R.id.edt);
        column1.setText(nombre[position]);
        edt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String prodlabel = nombre[position];
                dialog_Edit(prodlabel);
            }
        });
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String prodlabel = nombre[position];
                if(identificador == "categoria") {
                    EliminarItemStock(prodlabel);
                }
                else if(identificador == "marca")
                {
                    EliminarItemStockM(prodlabel);
                }
            }
        });
        return view;
    }
    private void EliminarItemStock(String categoria)
    {
        Call<User> call = MainActivity.apiInterface.ElimnarItemStock(categoria);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    MainActivity.prefConfig.DisplayToast("Item eliminado de Stock...");
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }
    private void EliminarItemStockM(String marca)
    {
        Call<User> call = MainActivity.apiInterface.EliminarItemStockM(marca);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    MainActivity.prefConfig.DisplayToast("Item eliminado de Stock...");
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }
    private void dialog_Edit(String marcastock)
    {
        Bundle args =new Bundle();
        args.putString("variable_stock",marcastock);
        args.putString("identificador",identificador);
        editamarcastock editamarcastock = new editamarcastock();
        editamarcastock.setTargetFragment(fragment,1);
        editamarcastock.setCancelable(false);
        editamarcastock.setArguments(args);
        editamarcastock.show(fragment.getFragmentManager(),null);
    }
    @Override
    public int getCount() {
        return nombre.length;
    }

}
