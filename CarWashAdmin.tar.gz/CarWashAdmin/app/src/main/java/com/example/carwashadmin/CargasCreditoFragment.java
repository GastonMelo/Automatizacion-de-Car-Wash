package com.example.carwashadmin;


import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Lifecycle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.text.DateFormat;
import java.util.Calendar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * A simple {@link Fragment} subclass.
 */
public class CargasCreditoFragment extends Fragment implements DatePickerFragment.DateListenner {

    private Button CargasdeCredito;
    private TextView ventasturno1,ventasturno2,ventasturno3,turno1,turno2,turno3,fecha_seleccion,ventastotales,LimpiezaM,LimpiezaT,LimpiezaN,VentasValesM,VentasValesT,VentasValesN,totalvales;
    public float[] porcent = new float[3];
    public String[] encargado_ventas = new String[3];
    public String[] conteo_limpieza = new String[3];
    public float[] conteo_vales = new float[3];
    public CargasCreditoFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_cargas_credito, container, false);
        CargasdeCredito = view.findViewById(R.id.ObtenerCredito);
        ventasturno1 = view.findViewById(R.id.ventasturno1);
        ventasturno2 = view.findViewById(R.id.ventasturno2);
        ventasturno3 = view.findViewById(R.id.ventasturno3);
        turno1 = view.findViewById(R.id.turno1);
        turno2 = view.findViewById(R.id.turno2);
        turno3 = view.findViewById(R.id.turno3);
        LimpiezaM = view.findViewById(R.id.LimpiezaM);
        LimpiezaT = view.findViewById(R.id.LimpiezaT);
        LimpiezaN = view.findViewById(R.id.LimpiezaN);
        fecha_seleccion = view.findViewById(R.id.Fecha_Seleccion);
        ventastotales = view.findViewById(R.id.ventastotales);
        VentasValesM = view.findViewById(R.id.VentasValesM);
        VentasValesT = view.findViewById(R.id.VentaValesT);
        VentasValesN = view.findViewById(R.id.VentaValesN);
        totalvales = view.findViewById(R.id.totalvales);
        CargasdeCredito.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment dialogFragment = new DatePickerFragment();
                dialogFragment.setTargetFragment(CargasCreditoFragment.this,1);
                dialogFragment.show(getFragmentManager(),"seleccionar fecha");

            }
        });
        return view;
    }

    @Override
    public void ReadCreditbyDateCalendar(String fecha_consulta) {
        String fecha = fecha_consulta;
        fecha_seleccion.setText(fecha);
        Call<User> call = MainActivity.apiInterface.CargasdeCreditoFecha(fecha);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    if(response.body().getCreditototal()[0] != null) {
                        ventastotales.setText(response.body().getCreditototal()[0]);
                    }
                    for(int i=0;i< (response.body().getCreditototal().length-1);i++) {
                        if(response.body().getCreditototal()[i+1] != null) {
                            porcent[i] = Integer.parseInt(response.body().getCreditototal()[i+1]);
                        }
                        else
                        {
                            porcent[i] = 0;
                        }
                    }
                    for(int j=0;j<(response.body().getEncargado_ventas().length);j++)
                    {
                        encargado_ventas[j] = response.body().getEncargado_ventas()[j];
                    }
                    math_operation(porcent);
                }
                else
                {
                    MainActivity.prefConfig.DisplayToast("Surgio un problema al enviar promoción..");
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });

    }

    @Override
    public void ReadCleaningbyDateCalendar(String fecha_limpieza) {
        String datetime = fecha_limpieza;
        Call<User> call = MainActivity.apiInterface.ControlLimpieza(datetime);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    for(int y=0;y<(response.body().getConteo_limpieza().length);y++)
                    {
                        if(response.body().getConteo_limpieza()[y] != null)
                        {
                            conteo_limpieza[y] = response.body().getConteo_limpieza()[y];
                        }
                        else
                        {
                            conteo_limpieza[y] = "0";
                        }
                    }
                    for(int j=0;j<(response.body().getEncargado_ventas().length);j++)
                    {
                        encargado_ventas[j] = response.body().getEncargado_ventas()[j];
                    }
                    indicarlimpieza();
                }

            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }

    @Override
    public void ReadValesbyDateCalendar(String fecha_vales) {
        String fecha = fecha_vales;
        Call<User> call = MainActivity.apiInterface.CargasdeValesFecha(fecha);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    if(response.body().getVales()[0] != null)
                    {
                        totalvales.setText(response.body().getVales()[0]);
                    }
                    for(int i=0;i< (response.body().getVales().length-1);i++) {
                        if(response.body().getVales()[i+1] != null) {
                            conteo_vales[i] = Integer.parseInt(response.body().getVales()[i+1]);
                        }
                        else
                        {
                            conteo_vales[i] = 0;
                        }
                    }
                    for(int j=0;j<(response.body().getEncargado_ventas().length);j++)
                    {
                        encargado_ventas[j] = response.body().getEncargado_ventas()[j];
                    }
                    mostrar_vales(conteo_vales);
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }

    private void math_operation(float[] sales)
    {
        encargadostxt();
        ventasturno1.setText("$" + sales[0]);
        ventasturno2.setText("$" + sales[1]);
        ventasturno3.setText("$" + sales[2]);
    }
    private void mostrar_vales(float[] vales)
    {
        encargadostxt();
        VentasValesM.setText("$" + vales[0]);
        VentasValesT.setText("$" + vales[1]);
        VentasValesN.setText("$" + vales[2]);
    }
    private void indicarlimpieza()
    {
        encargadostxt();
        LimpiezaM.setText(conteo_limpieza[0]);
        LimpiezaT.setText(conteo_limpieza[1]);
        LimpiezaN.setText(conteo_limpieza[2]);
    }
    private void encargadostxt()
    {
        turno1.setText(encargado_ventas[0]);
        turno2.setText(encargado_ventas[1]);
        turno3.setText(encargado_ventas[2]);
    }
}
