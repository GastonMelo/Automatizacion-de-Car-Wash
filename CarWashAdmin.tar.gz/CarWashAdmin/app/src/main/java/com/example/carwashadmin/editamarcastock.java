package com.example.carwashadmin;

import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class editamarcastock extends AppCompatDialogFragment {
    AlertDialog alertDialog;
    Button Continuar,Cancelar;
    EditText marcatxt,interestxt,descuentotxt;
    public String identificador;
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.editamarcastock,null);
        marcatxt = view.findViewById(R.id.marcatxt);
        interestxt = view.findViewById(R.id.interestxt);
        descuentotxt = view.findViewById(R.id.descuentotxt);
        Continuar = view.findViewById(R.id.Continuar);
        Cancelar = view.findViewById(R.id.Cancelar);
        Bundle args = getArguments();
        final String aux1 = args.getString("variable_stock");
        identificador = args.getString("identificador");
        marcatxt.setText(aux1);
        Continuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(identificador == "marca")
                {
                    EditarMarcaStock(aux1);
                    getDialog().dismiss();
                }
                else if(identificador == "categoria")
                {
                    EditarCategoriaStock(aux1);
                    getDialog().dismiss();
                }

            }
        });
        Cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getDialog().dismiss();
            }
        });
        builder.setView(view);
        alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        return alertDialog;
    }
    private void EditarMarcaStock(String marca)
    {
        int interes = Integer.parseInt(interestxt.getText().toString());
        int descuento = Integer.parseInt(descuentotxt.getText().toString());
        Call<User> call = MainActivity.apiInterface.EditarPUMarca(marca,interes,descuento);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    MainActivity.prefConfig.DisplayToast("Se modifico el precio en stock");
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }
    private void EditarCategoriaStock(String categoria)
    {
        int interes = Integer.parseInt(interestxt.getText().toString());
        int descuento = Integer.parseInt(descuentotxt.getText().toString());
        Call<User> call = MainActivity.apiInterface.EditarPÜCategoria(categoria,interes,descuento);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    MainActivity.prefConfig.DisplayToast("Se modifico el precio en stock");
                }

            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }
}
