package com.example.carwashadmin;

public class categoria {
    private String nombre;
    public categoria(String nombre){
        this.nombre=nombre;
    }

    public String getNombre() {
        return nombre;
    }
}
