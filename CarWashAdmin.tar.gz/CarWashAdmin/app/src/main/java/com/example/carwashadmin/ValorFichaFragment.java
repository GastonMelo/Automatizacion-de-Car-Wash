package com.example.carwashadmin;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * A simple {@link Fragment} subclass.
 */
public class ValorFichaFragment extends Fragment {
    private Button CambiarValorFicha;
    private EditText NuevoValorFicha;

    public ValorFichaFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_valor_ficha, container, false);
        NuevoValorFicha = view.findViewById(R.id.ValorFicha);
        CambiarValorFicha = view.findViewById(R.id.EnviarValorFicha);
        CambiarValorFicha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                //builder.setIcon(getResources().getDrawable(R.drawable.ic_alert_dialog));
                builder.setTitle("Confirmar cambio");
                builder.setMessage("¿Seguro Desea realizar el cambio de valor a $ " + NuevoValorFicha.getText().toString() +  "?");
                builder.setCancelable(true);
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String nuevo_valor = NuevoValorFicha.getText().toString();
                        NuevoValorFicha(nuevo_valor);
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        MainActivity.prefConfig.DisplayToast("Operacion cancelada");
                    }
                });
                AlertDialog ValorFicha = builder.create();
                ValorFicha.show();
            }
        });
        return view;
    }

    private void NuevoValorFicha(final String valorficha)
    {
        Call<User> call = MainActivity.apiInterface.NuevoValorFicha(valorficha);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    MainActivity.prefConfig.DisplayToast("Nuevo valor de ficha en : $ " + valorficha);
                    NotificarValorFicha();
                }
                else
                {
                    MainActivity.prefConfig.DisplayToast("Surgio un problema....");
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }

    private void NotificarValorFicha()
    {
        String titulo = "Nuevo valor de ficha";
        String mensaje = "Car wash actualizo el valor de ficha";
        String valor_ficha = "UpdateFicha_" + NuevoValorFicha.getText().toString();
        String destinatarios = "T";
        Call<User> call = MainActivity.apiInterface.SendNotificationUsers(titulo,mensaje,valor_ficha,destinatarios);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    MainActivity.prefConfig.DisplayToast("Mensaje enviado a clientes");
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
        NuevoValorFicha.setText("");
    }
}
