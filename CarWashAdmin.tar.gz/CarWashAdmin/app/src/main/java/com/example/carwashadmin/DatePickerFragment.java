package com.example.carwashadmin;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.widget.DatePicker;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener{
    private DateListenner dateListenner;
    public int dia,mes,año;
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Calendar calendar = Calendar.getInstance();
        año = calendar.get(Calendar.YEAR);
        mes = calendar.get(Calendar.MONTH);
        dia = calendar.get(Calendar.DAY_OF_MONTH);
        return new DatePickerDialog(getActivity(), AlertDialog.THEME_TRADITIONAL, this,año,mes,dia);

    }


    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR,year);
        calendar.set(Calendar.MONTH,month);
        calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);
        SimpleDateFormat formatofecha = new SimpleDateFormat("YYYY-MM-dd");
        String fecha = formatofecha.format(calendar.getTime());
        dateListenner.ReadCreditbyDateCalendar(fecha);
        dateListenner.ReadValesbyDateCalendar(fecha);
        dateListenner.ReadCleaningbyDateCalendar(fecha);

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        dateListenner = (DateListenner) getTargetFragment();
    }

    public interface DateListenner
    {
        void ReadCreditbyDateCalendar(String fecha);
        void ReadCleaningbyDateCalendar(String fecha);
        void ReadValesbyDateCalendar(String fecha);
    }
}
