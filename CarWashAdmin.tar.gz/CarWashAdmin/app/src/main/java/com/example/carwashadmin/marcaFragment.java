package com.example.carwashadmin;


import android.app.Activity;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * A simple {@link Fragment} subclass.
 */
public class marcaFragment extends Fragment implements modificaitemstock.CategoriaItemListenner, AgregarMCDialog.AgregarMCDialogListenner {

    Button read_marcas,add_marcas;
    ListView marcas;
    public String[] marcas_array;
    public String[] descripcion;
    public String[] cantidad;
    public String[] preciounitario;
    public String[] codigo;
    public int click_listview = 0;
    String identificador = "marca";
    public marcaFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_marca, container, false);
        marcas = view.findViewById(R.id.marcas);
        read_marcas = view.findViewById(R.id.readmarcas);
        add_marcas = view.findViewById(R.id.addmarca);
        read_marcas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click_listview = 0;
                ReadMarcas();
            }
        });
        add_marcas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog_agregarmc();
            }
        });
        marcas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(click_listview == 0)
                {
                    String marca_item = marcas_array[position];
                    CargarItemSeleccion(marca_item);
                    click_listview++;
                }
                else if(click_listview == 1)
                {
                    if((descripcion != null)&&(cantidad != null)&&(preciounitario != null)&&(codigo != null))
                    {
                        String producto = descripcion[position];
                        String qty = cantidad[position];
                        String p_u = preciounitario[position];
                        String code = codigo[position];
                        dialog_categoriaitem(producto,qty,p_u,code);
                    }
                }

            }
        });
        return view;
    }
    private void ReadMarcas()
    {
        Call<List<marca>> call = MainActivity.apiInterface.cargarmarca();
        call.enqueue(new Callback<List<marca>>() {
            @Override
            public void onResponse(Call<List<marca>> call, Response<List<marca>> response) {
                List<marca> marcaList = response.body();
                marcas_array = new String[marcaList.size()];
                for(int i=0;i<marcaList.size();i++){
                    marcas_array[i] = marcaList.get(i).getNombre();
                }
                //ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1, marcas_array);
                CustomAdapterButtons adapter = new CustomAdapterButtons(getActivity(),-1,marcas_array, marcaFragment.this,identificador);
                marcas.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<marca>> call, Throwable t) {

            }
        });
    }
    private void CargarItemSeleccion(String marca_item)
    {
        Call<List<catalogo>> call = MainActivity.apiInterface.CargarMarcaItem(marca_item);
        call.enqueue(new Callback<List<catalogo>>() {
            @Override
            public void onResponse(Call<List<catalogo>> call, Response<List<catalogo>> response) {
                List<catalogo> catalogoList = response.body();
                descripcion = new String[catalogoList.size()];
                cantidad = new String[catalogoList.size()];
                preciounitario = new String[catalogoList.size()];
                codigo = new String[catalogoList.size()];
                for(int j=0;j<catalogoList.size();j++) {
                    descripcion[j] = catalogoList.get(j).getDescripcion();
                    cantidad[j] = catalogoList.get(j).getCantidad();
                    preciounitario[j] = "$" + catalogoList.get(j).getPrecio_unitario();
                    codigo[j] = catalogoList.get(j).getCodigo();
                }
                CustomAdapter adapter = new CustomAdapter(getActivity(),-1,descripcion,cantidad,preciounitario,codigo);
                marcas.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<catalogo>> call, Throwable t) {

            }
        });
    }
    private void dialog_categoriaitem(String descripcion, String cantidad,String preciounitario,String codigo)
    {
        Bundle args =new Bundle();
        args.putString("descripcion",descripcion);
        args.putString("cantidad",cantidad);
        args.putString("preciounitario",preciounitario);
        args.putString("codigo",codigo);
        modificaitemstock modificaitemstock = new modificaitemstock();
        modificaitemstock.setTargetFragment(marcaFragment.this,1);
        modificaitemstock.setCancelable(false);
        modificaitemstock.setArguments(args);
        modificaitemstock.show(getFragmentManager(),null);
    }
    private void dialog_agregarmc()
    {
        Bundle args =new Bundle();
        args.putString("identificador",identificador);
        AgregarMCDialog agregarMCDialog = new AgregarMCDialog();
        agregarMCDialog.setTargetFragment(marcaFragment.this,1);
        agregarMCDialog.setCancelable(false);
        agregarMCDialog.setArguments(args);
        agregarMCDialog.show(getFragmentManager(),null);
    }
}
