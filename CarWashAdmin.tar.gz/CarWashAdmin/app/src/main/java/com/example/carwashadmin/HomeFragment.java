package com.example.carwashadmin;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {

    private Button Clientes,ControlInterno, ConfigValores;

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view =  inflater.inflate(R.layout.fragment_home, container, false);
        Clientes = view.findViewById(R.id.EnviarPromocion);
        ControlInterno = view.findViewById(R.id.EnviarDescuento);
        ConfigValores = view.findViewById(R.id.CargasCredito);
        Clientes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.fragmentManager.beginTransaction().replace(R.id.fragment_container, new ClientesFragment(), null).addToBackStack(null).commit();
            }
        });
        ControlInterno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.fragmentManager.beginTransaction().replace(R.id.fragment_container, new ControlInternoFragment(), null).addToBackStack(null).commit();
            }
        });
        ConfigValores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.fragmentManager.beginTransaction().replace(R.id.fragment_container, new ConfigValoresFragment(), null).addToBackStack(null).commit();
            }
        });
        return view;
    }

}
