package com.example.carwashadmin;

import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class cargarnuevoproductostock extends AppCompatDialogFragment {
    AlertDialog alertDialog;
    Button Continuar,Cancelar;
    EditText descripciontxt,cantidadtxt,preciounitariotxt,codigotxt;
    AutoCompleteTextView marcatxt,categoriatxt;
    private CargarNuevoProductoStockListenner cargarNuevoProductoStockListenner;
    public interface CargarNuevoProductoStockListenner
    {

    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.cargarnuevoproductostock,null);
        descripciontxt = view.findViewById(R.id.descripciontxt);
        cantidadtxt = view.findViewById(R.id.cantidadtxt);
        preciounitariotxt = view.findViewById(R.id.preciounitariotxt);
        codigotxt = view.findViewById(R.id.codigotxt);
        marcatxt = view.findViewById(R.id.marcatxt);
        categoriatxt = view.findViewById(R.id.categoriatxt);
        Continuar = view.findViewById(R.id.Continuar);
        Cancelar = view.findViewById(R.id.Cancelar);
        Continuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegistrarProductoStock();
                getDialog().dismiss();
            }
        });
        Cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getDialog().dismiss();
            }
        });
        marcatxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                String id = s.toString();
                AutocompletarMarca(id);
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        categoriatxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                String id = s.toString();
                AutcompletarCategoria(id);
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        builder.setView(view);
        alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        return alertDialog;
    }
    private void RegistrarProductoStock()
    {
        String descripcion = descripciontxt.getText().toString();
        int preciounitario = Integer.parseInt(preciounitariotxt.getText().toString());
        int cantidad = Integer.parseInt(cantidadtxt.getText().toString());
        String codigo = codigotxt.getText().toString();
        String marca = marcatxt.getText().toString();
        String categoria = categoriatxt.getText().toString();
        Call<User> call = MainActivity.apiInterface.AgregarProductoNuevoStock(preciounitario,cantidad,descripcion,codigo,categoria,marca);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    MainActivity.prefConfig.DisplayToast("Nuevo producto agregado..");
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }
    private void AutocompletarMarca(String id)
    {
        Call<User> call = MainActivity.apiInterface.AutocompletarMarca(id);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    int longitud = (response.body().getNombre_marca().length);
                    String[] marca = new String[longitud];
                    for(int j=0; j<=(response.body().getNombre_marca().length - 1);j++)
                    {
                        if(response.body().getNombre_marca()[j] != null) {
                            marca[j] = response.body().getNombre_marca()[j];
                        }
                    }
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_dropdown_item_1line, marca);
                    marcatxt.setAdapter(adapter);
                }

            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }
    private void AutcompletarCategoria(String id)
    {
        Call<User> call = MainActivity.apiInterface.AutocompletarCategoria(id);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    int longitud = (response.body().getNombre_categoria().length);
                    String[] categoria = new String[longitud];
                    for(int j=0; j<=(response.body().getNombre_categoria().length - 1);j++)
                    {
                        if(response.body().getNombre_categoria()[j] != null) {
                            categoria[j] = response.body().getNombre_categoria()[j];
                        }
                    }
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_dropdown_item_1line, categoria);
                    categoriatxt.setAdapter(adapter);
                }

            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }
}
