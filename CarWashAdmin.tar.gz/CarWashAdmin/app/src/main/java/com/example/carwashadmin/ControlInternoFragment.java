package com.example.carwashadmin;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


/**
 * A simple {@link Fragment} subclass.
 */
public class ControlInternoFragment extends Fragment {
    private Button CargasCredito,ElementosenUso,Stock;

    public ControlInternoFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_control_interno, container, false);
        CargasCredito = view.findViewById(R.id.CargasCredito);
        ElementosenUso = view.findViewById(R.id.ElementosenUso);
        Stock = view.findViewById(R.id.Stock);
        CargasCredito.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.fragmentManager.beginTransaction().replace(R.id.fragment_container, new CargasCreditoFragment(), null).addToBackStack(null).commit();
            }
        });
        ElementosenUso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.fragmentManager.beginTransaction().replace(R.id.fragment_container,new ElementosenUsoFragment(), null).addToBackStack(null).commit();
            }
        });
        Stock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.fragmentManager.beginTransaction().replace(R.id.fragment_container,new StockFragment(),null).addToBackStack(null).commit();
            }
        });
        return view;
    }

}
