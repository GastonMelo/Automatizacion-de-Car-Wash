package com.example.carwashadmin;

public class marca {
    private String nombre;
    public marca(String nombre){
        this.nombre=nombre;
    }

    public String getNombre() {
        return nombre;
    }
}
