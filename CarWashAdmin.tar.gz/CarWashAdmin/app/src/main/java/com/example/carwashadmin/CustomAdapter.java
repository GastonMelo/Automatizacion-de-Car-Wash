package com.example.carwashadmin;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CustomAdapter extends ArrayAdapter {
    private Context context;
    private String[] descripcion;
    private String[] cantidad;
    private String[] preciounitario;
    private String[] codigo;
    private Button edt;
    private Button del;

    public CustomAdapter(Context context, int resources, String[] descripcion, String[] cantidad, String[] preciounitario, String[] codigo) {
        super(context,resources);
        this.context = context;
        this.descripcion = descripcion;
        this.cantidad = cantidad;
        this.preciounitario = preciounitario;
        this.codigo=codigo;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = LayoutInflater.from((Context) context).inflate(R.layout.listview_col, parent, false);
        del = view.findViewById(R.id.del);
        edt = view.findViewById(R.id.edt);
        TextView column1 = view.findViewById(R.id.nombre);
        TextView column2 = view.findViewById(R.id.apellido);
        TextView column3 = view.findViewById(R.id.descuento);
        TextView column4 = view.findViewById(R.id.Codigo);
        column1.setText(descripcion[position]);
        column2.setText(cantidad[position]);
        column3.setText(preciounitario[position]);
        column4.setText(codigo[position]);
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String idproducto = codigo[position];
                EliminarProductoStock(idproducto);
            }
        });
        return view;
    }
    private void EliminarProductoStock(String codigo)
    {
        Call<User> call = MainActivity.apiInterface.EliminarProductoStock(codigo);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    MainActivity.prefConfig.DisplayToast("Item stock eliminado..");
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }
    @Override
    public int getCount() {
        return descripcion.length;
    }
}
