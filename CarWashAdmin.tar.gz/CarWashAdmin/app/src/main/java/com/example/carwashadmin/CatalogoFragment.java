package com.example.carwashadmin;


import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static java.sql.Types.NULL;


/**
 * A simple {@link Fragment} subclass.
 */
public class CatalogoFragment extends Fragment implements cargarproductosqrstock.CargarProductoStock,cargarnuevoproductostock.CargarNuevoProductoStockListenner, ventaproductostock.VentaProductoStockListenner {
    Button vercatalogo,agregarproducto,ventastock;
    ListView catalogo;
    public String operacion = "";
    public CatalogoFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_catalogo, container, false);
        vercatalogo = view.findViewById(R.id.VerCatalogo);
        ventastock = view.findViewById(R.id.ventastock);
        agregarproducto = view.findViewById(R.id.AgregarProducto);
        catalogo = view.findViewById(R.id.catalogo);
        vercatalogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cargarcatalogo();
            }
        });
        agregarproducto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InitiateQRScan();
                operacion = "stock";
            }
        });
        ventastock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InitiateQRScan();
                operacion = "venta";
            }
        });
        return view;
    }

    private void InitiateQRScan()
    {
        IntentIntegrator vistaescanner = IntentIntegrator.forSupportFragment(CatalogoFragment.this);
        vistaescanner.setPrompt("Scan");
        vistaescanner.setBeepEnabled(true);
        vistaescanner.setOrientationLocked(true);
        vistaescanner.setCaptureActivity(CaptureActivityPortrait.class);
        vistaescanner.initiateScan();
    }
    /********************************************************************************/
    /*                      QR scan resultado                                       */
    /********************************************************************************/
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        IntentResult scan_result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if(scan_result.getContents() != null)
        {
            String codigo = scan_result.getContents();
            SearchForCode(codigo);
        }
    }
    private void cargarcatalogo()
    {
        Call<List<catalogo>> call = MainActivity.apiInterface.cargarcatalogo();
        call.enqueue(new Callback<List<catalogo>>() {
            @Override
            public void onResponse(Call<List<catalogo>> call, Response<List<catalogo>> response) {
                List<catalogo> catalogoList = response.body();
                String[] descripcion = new String[catalogoList.size()];
                String[] cantidad = new String[catalogoList.size()];
                String[] preciounitario = new String[catalogoList.size()];
                String[] codigo = new String[catalogoList.size()];
                for(int j=0;j<catalogoList.size();j++) {
                    descripcion[j] = catalogoList.get(j).getDescripcion();
                    cantidad[j] = catalogoList.get(j).getCantidad();
                    preciounitario[j] = "$" + catalogoList.get(j).getPrecio_unitario();
                    codigo[j] = catalogoList.get(j).getCodigo();
                }
                CustomAdapter adapter = new CustomAdapter(getActivity(),-1,descripcion,cantidad,preciounitario,codigo);//
                catalogo.setAdapter(adapter);

            }

            @Override
            public void onFailure(Call<List<catalogo>> call, Throwable t) {

            }
        });
    }
    private void SearchForCode(final String codigo)
    {
        Call<List<catalogo>> call = MainActivity.apiInterface.BuscarStockCodigo(codigo);
        call.enqueue(new Callback<List<com.example.carwashadmin.catalogo>>() {
            @Override
            public void onResponse(Call<List<com.example.carwashadmin.catalogo>> call, Response<List<com.example.carwashadmin.catalogo>> response) {
                List<catalogo> catalogoList = response.body();
                if(catalogoList.get(0).getStatus().equals("ok"))
                {
                    String descripcion = catalogoList.get(0).getDescripcion();
                    String cantidad = catalogoList.get(0).getCantidad();
                    String preciounitario = catalogoList.get(0).getPrecio_unitario();
                    String codigo = catalogoList.get(0).getCodigo();
                    if(operacion == "venta")
                    {
                        operacion = "";
                        dialog_Ventas(descripcion,cantidad,preciounitario,codigo);
                    }
                    else if(operacion == "stock") {
                        operacion = "";
                        dialog_PEQR(descripcion,cantidad,preciounitario,codigo);
                    }

                }
                else
                {
                    dialog_NPEQR();
                }
            }

            @Override
            public void onFailure(Call<List<com.example.carwashadmin.catalogo>> call, Throwable t) {

            }
        });
    }
    private void dialog_PEQR(String descripcion,String cantidad,String preciounitario,String codigo)
    {
        Bundle args =new Bundle();
        args.putString("descripcion",descripcion);
        args.putString("cantidad",cantidad);
        args.putString("preciounitario",preciounitario);
        args.putString("codigo",codigo);
        cargarproductosqrstock cargarproductosqrstock = new cargarproductosqrstock();
        cargarproductosqrstock.setTargetFragment(CatalogoFragment.this,1);
        cargarproductosqrstock.setCancelable(false);
        cargarproductosqrstock.setArguments(args);
        cargarproductosqrstock.show(getFragmentManager(),null);
    }
    private void dialog_NPEQR()
    {
        cargarnuevoproductostock cargarnuevoproductostock = new cargarnuevoproductostock();
        cargarnuevoproductostock.setTargetFragment(CatalogoFragment.this,1);
        cargarnuevoproductostock.setCancelable(false);
        cargarnuevoproductostock.show(getFragmentManager(),null);
    }
    private void dialog_Ventas(String descripcion,String cantidad,String preciounitario,String codigo)
    {
        Bundle args =new Bundle();
        args.putString("descripcion",descripcion);
        args.putString("cantidad",cantidad);
        args.putString("preciounitario",preciounitario);
        args.putString("codigo",codigo);
        ventaproductostock ventaproductostock = new ventaproductostock();
        ventaproductostock.setTargetFragment(CatalogoFragment.this,1);
        ventaproductostock.setCancelable(false);
        ventaproductostock.setArguments(args);
        ventaproductostock.show(getFragmentManager(),null);

    }

}
