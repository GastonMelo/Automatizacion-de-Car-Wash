package com.example.carwashadmin;


import android.app.ActionBar;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * A simple {@link Fragment} subclass.
 */
public class categoriaFragment extends Fragment implements modificaitemstock.CategoriaItemListenner,AgregarMCDialog.AgregarMCDialogListenner {
    ListView categorias;
    Button cargarcategorias,addcategorias;
    public String[] categoria_array;
    public String[] descripcion;
    public String[] cantidad;
    public String[] preciounitario;
    public String[] codigo;
    String identificador = "categoria";
    public int click_listview = 0;
    public categoriaFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_categoria, container, false);

        categorias = view.findViewById(R.id.categorias);
        cargarcategorias = view.findViewById(R.id.cargarcategoria);
        addcategorias = view.findViewById(R.id.addcategoria);
        cargarcategorias.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click_listview = 0;
                CargarCategorias();
            }
        });
        addcategorias.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog_agregarmc();
            }
        });
        categorias.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(click_listview == 0) {
                    String categoria_item = categoria_array[position];
                    CargarItemSeleccion(categoria_item);
                    //setHasOptionsMenu(true);
                    //((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                    click_listview++;
                }
                else if(click_listview == 1)
                {
                    if((descripcion != null)&&(cantidad != null)&&(preciounitario != null)&&(codigo != null))
                    {
                        String producto = descripcion[position];
                        String qty = cantidad[position];
                        String p_u = preciounitario[position];
                        String code = codigo[position];
                        dialog_categoriaitem(producto,qty,p_u,code);
                    }
                }

            }
        });
        return view;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        CargarCategorias();
        return super.onOptionsItemSelected(item);
    }

    private void CargarCategorias()
    {
        Call<List<categoria>> call = MainActivity.apiInterface.cargarcategoria();
        call.enqueue(new Callback<List<categoria>>() {
            @Override
            public void onResponse(Call<List<categoria>> call, Response<List<categoria>> response) {
                List<categoria> categoriaList = response.body();
                categoria_array = new String[categoriaList.size()];
                for(int x = 0;x<categoriaList.size();x++)
                {
                    categoria_array[x]=categoriaList.get(x).getNombre();
                }
                //ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1,categoria_array);
                CustomAdapterButtons adapter = new CustomAdapterButtons(getActivity(),-1,categoria_array,categoriaFragment.this,identificador);
                categorias.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<categoria>> call, Throwable t) {

            }
        });
    }
    private void CargarItemSeleccion(String categoria_item)
    {
        Call<List<catalogo>> call = MainActivity.apiInterface.CargarCategoriaItem(categoria_item);
        call.enqueue(new Callback<List<catalogo>>() {
            @Override
            public void onResponse(Call<List<catalogo>> call, Response<List<catalogo>> response) {
                List<catalogo> catalogoList = response.body();
                descripcion = new String[catalogoList.size()];
                cantidad = new String[catalogoList.size()];
                preciounitario = new String[catalogoList.size()];
                codigo = new String[catalogoList.size()];
                for(int j=0;j<catalogoList.size();j++) {
                    descripcion[j] = catalogoList.get(j).getDescripcion();
                    cantidad[j] = catalogoList.get(j).getCantidad();
                    preciounitario[j] = "$" + catalogoList.get(j).getPrecio_unitario();
                    codigo[j] = catalogoList.get(j).getCodigo();
                }
                CustomAdapter adapter = new CustomAdapter(getActivity(),-1,descripcion,cantidad,preciounitario,codigo);
                categorias.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<catalogo>> call, Throwable t) {

            }
        });
    }

    private void dialog_categoriaitem(String descripcion, String cantidad,String preciounitario,String codigo)
    {
        Bundle args =new Bundle();
        args.putString("descripcion",descripcion);
        args.putString("cantidad",cantidad);
        args.putString("preciounitario",preciounitario);
        args.putString("codigo",codigo);
        modificaitemstock modificaitemstock = new modificaitemstock();
        modificaitemstock.setTargetFragment(categoriaFragment.this,1);
        modificaitemstock.setCancelable(false);
        modificaitemstock.setArguments(args);
        modificaitemstock.show(getFragmentManager(),null);
    }
    private void dialog_agregarmc()
    {
        Bundle args =new Bundle();
        args.putString("identificador",identificador);
        AgregarMCDialog agregarMCDialog = new AgregarMCDialog();
        agregarMCDialog.setTargetFragment(categoriaFragment.this,1);
        agregarMCDialog.setCancelable(false);
        agregarMCDialog.setArguments(args);
        agregarMCDialog.show(getFragmentManager(),null);
    }
}
