package com.example.carwashadmin;

public class catalogo {
    private String precio_unitario;
    private String cantidad;
    private String descripcion;
    private String codigo;
    private String status;
    public catalogo(String precio_unitario,String cantidad,String descripcion,String codigo,String status)
    {
        this.precio_unitario=precio_unitario;
        this.cantidad=cantidad;
        this.descripcion=descripcion;
        this.codigo=codigo;
        this.status=status;
    }

    public String getPrecio_unitario() {
        return precio_unitario;
    }

    public String getCantidad() {
        return cantidad;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getStatus() {
        return status;
    }
}
