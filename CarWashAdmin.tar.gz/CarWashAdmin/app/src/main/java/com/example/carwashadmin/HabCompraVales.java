package com.example.carwashadmin;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.ContentValues.TAG;

public class HabCompraVales extends AppCompatDialogFragment {
    private AutoCompleteTextView SeleccionarNombreApellido;
    private Button Aceptar,Cancelar;
    private CheckBox enable;
    public String habilitado = "No";
    private HabComprarValesListenner habComprarValesListenner;

    public interface HabComprarValesListenner
    {

    }
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.hab_compra_vales,null);
        Aceptar = view.findViewById(R.id.Continuar);
        SeleccionarNombreApellido = view.findViewById(R.id.SeleccionarNombreApellido);
        Cancelar = view.findViewById(R.id.Cancelar);
        enable = view.findViewById(R.id.enable);
        SeleccionarNombreApellido.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String id = s.toString();
                autocompletar_nombre(id);
            }
            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        enable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enable.isChecked())
                {
                    habilitado = "Si";
                }
                else
                {
                    habilitado = "No";
                }
            }
        });
        Aceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre_busqueda = null;
                String apellido_busqueda = null;
                String nombrecompleto = SeleccionarNombreApellido.getText().toString();
                if (nombrecompleto != null) {
                    String[] split = nombrecompleto.split(" ");
                    nombre_busqueda = split[0];
                    apellido_busqueda = split[1];
                }
                registrarclientevale(nombre_busqueda,apellido_busqueda,habilitado);
                getDialog().dismiss();
            }
        });
        Cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getDialog().dismiss();
            }
        });
        builder.setView(view);
        Dialog d = builder.create();
        d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        return d;
    }

    /***************************************************************************************************************************************/
    /*******                                    habilitar compra de vales a clientes                                                ********/
    /***************************************************************************************************************************************/
    private void autocompletar_nombre(String id)
    {
        Call<User> call = MainActivity.apiInterface.AutoCompletarNombre(id);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    int longitud = (response.body().getNombreApellido().length);
                    String[] IdNombre = new String[longitud];
                    for(int j=0; j<=(response.body().getNombreApellido().length - 1);j++)
                    {
                        if(response.body().getNombreApellido()[j] != null) {
                            IdNombre[j] = response.body().getNombreApellido()[j];
                        }
                    }
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_dropdown_item_1line, IdNombre);
                    SeleccionarNombreApellido.setAdapter(adapter);
                }
            }
            @Override
            public void onFailure(Call<User> call, Throwable t) {
            }
        });
    }
    /****************************************************************************************************************************************/
    /******                                     registra cliente como habilitado o lo inhabilita                                    *********/
    /****************************************************************************************************************************************/
    private void registrarclientevale(String nombre,String apellido,String enable)
    {
        Call<User> call = MainActivity.apiInterface.HabClienteVale(nombre,apellido,enable);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    MainActivity.prefConfig.DisplayToast("Cliente habilitado para comprar vales....");
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }

    @Override
    public void onAttach( Context context) {
        super.onAttach(context);
        try {
            habComprarValesListenner = (HabCompraVales.HabComprarValesListenner) getTargetFragment();
        }catch (ClassCastException e){
            Log.e(TAG, "ClassCastException: " + e.getMessage());
        }

    }
}
