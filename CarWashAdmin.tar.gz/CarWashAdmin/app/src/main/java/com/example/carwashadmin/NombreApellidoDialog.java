package com.example.carwashadmin;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatDialogFragment;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.ContentValues.TAG;

public class NombreApellidoDialog extends AppCompatDialogFragment
{
    private AutoCompleteTextView SeleccionarNombreApellido,SeleccionarModeloVehiculo;
    private Button DialogAccept, DialogCancel;
    private boolean Notificar_persona = true;

    private SeleccionarDialogListener seleccionarDialogListener;
    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.select_user_dialog, null);
        SeleccionarNombreApellido = view.findViewById(R.id.AutocompletarNombre);
        SeleccionarModeloVehiculo = view.findViewById(R.id.AutocompletarVehiculo);
        SeleccionarNombreApellido.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String id = s.toString();
                autocompletar_nombre(id);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        SeleccionarModeloVehiculo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                String id = s.toString();
                autocompletar_vehiculo(id);
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        DialogAccept = view.findViewById(R.id.Dialog_accept);
        DialogCancel = view.findViewById(R.id.Dialog_cancel);
        DialogAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if(Notificar_persona)
                {
                    String nombrecompleto = SeleccionarNombreApellido.getText().toString();
                    String nombre_busqueda = null;
                    String apellido_busqueda = null;
                    if (nombrecompleto != null) {
                        String[] split = nombrecompleto.split(" ");
                        nombre_busqueda = split[0];
                        apellido_busqueda = split[1];
                    }
                    seleccionarDialogListener.NombreApellido(nombre_busqueda, apellido_busqueda);
                    getDialog().dismiss();
                }
                else
                {
                    seleccionarDialogListener.ModeloVehiculo(SeleccionarModeloVehiculo.getText().toString());
                    getDialog().dismiss();
                }
            }
        });
        DialogCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.prefConfig.DisplayToast("Busqueda cancelada");
                getDialog().dismiss();
            }
        });
        builder.setView(view);
        Dialog d = builder.create();
        d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        return d;
    }

    private void autocompletar_vehiculo(String id)
    {
        Call<User> call = MainActivity.apiInterface.AutoCompletarVehiculo(id);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    int longitud = (response.body().getModelo().length);
                    String[] IdModelo = new String[longitud];
                    for(int i=0; i<=(response.body().getModelo().length - 1);i++)
                    {
                        if(response.body().getModelo()[i]!=null)
                        {
                            IdModelo[i] = response.body().getModelo()[i];
                        }
                    }
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_dropdown_item_1line, IdModelo);
                    SeleccionarModeloVehiculo.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
        Notificar_persona = false;
    }

    private void autocompletar_nombre(String id)
    {
        Call<User> call = MainActivity.apiInterface.AutoCompletarNombre(id);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    int longitud = (response.body().getNombreApellido().length);
                    String[] IdNombre = new String[longitud];
                    for(int j=0; j<=(response.body().getNombreApellido().length - 1);j++)
                    {
                        if(response.body().getNombreApellido()[j] != null) {
                            IdNombre[j] = response.body().getNombreApellido()[j];
                        }
                    }
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_dropdown_item_1line, IdNombre);
                    SeleccionarNombreApellido.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
        Notificar_persona = true;
    }


    @Override
    public void onAttach( Context context) {
        super.onAttach(context);
        try {
            seleccionarDialogListener = (SeleccionarDialogListener) getTargetFragment();
        }catch (ClassCastException e){
            Log.e(TAG, "ClassCastException: " + e.getMessage());
        }

    }

    public interface SeleccionarDialogListener
    {
        void NombreApellido(String nombre, String apellido);
        void ModeloVehiculo(String modelo);
    }
}
