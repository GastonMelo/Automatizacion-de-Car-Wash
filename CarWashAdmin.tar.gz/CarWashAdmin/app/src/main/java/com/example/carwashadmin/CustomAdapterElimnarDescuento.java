package com.example.carwashadmin;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class CustomAdapterElimnarDescuento extends ArrayAdapter {
    private Context context;
    private CheckBox enabled;
    private Fragment fragment;
    private ArrayList<String[]> cliente_data;

    public CustomAdapterElimnarDescuento(Context context, int resources, ArrayList<String[]> cliente_data, Fragment fragment) //String[] nombre,String[] apellido,String[] dni,String[] descuento,Boolean[] checkeditem
    {
        super(context,resources);
        this.context = context;
        this.cliente_data = cliente_data;
        this.fragment = fragment;
    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = LayoutInflater.from((Context) context).inflate(R.layout.eliminardescuentocliente, parent, false);
        TextView column1 = view.findViewById(R.id.nombre);
        TextView column2 = view.findViewById(R.id.apellido);
        TextView column3 = view.findViewById(R.id.descuento);
        enabled = view.findViewById(R.id.enabled);
        column1.setText(cliente_data.get(position)[0]);
        column2.setText(cliente_data.get(position)[1]);
        column3.setText(cliente_data.get(position)[2]);
        enabled.setChecked(Boolean.valueOf(cliente_data.get(position)[4]));
        return view;
    }

    public int getCount() {
        return cliente_data.size();
    }
}
