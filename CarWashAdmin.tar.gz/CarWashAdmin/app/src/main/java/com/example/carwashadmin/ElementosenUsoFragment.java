package com.example.carwashadmin;


import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * A simple {@link Fragment} subclass.
 */
public class ElementosenUsoFragment extends Fragment {
    public int j=0;
    public ElementosenUsoFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_elementosen_uso, container, false);
        final Button arraybuttons[] = new Button[12];
        arraybuttons[0] = view.findViewById(R.id.button0);
        arraybuttons[1] = view.findViewById(R.id.button1);
        arraybuttons[2] = view.findViewById(R.id.button2);
        arraybuttons[3] = view.findViewById(R.id.button3);
        arraybuttons[4] = view.findViewById(R.id.button4);
        arraybuttons[5] = view.findViewById(R.id.button5);
        arraybuttons[6] = view.findViewById(R.id.button6);
        arraybuttons[7] = view.findViewById(R.id.button7);
        arraybuttons[8] = view.findViewById(R.id.button8);
        arraybuttons[9] = view.findViewById(R.id.button9);
        arraybuttons[10] = view.findViewById(R.id.button10);
        arraybuttons[11] = view.findViewById(R.id.button11);

            Call<User> call = MainActivity.apiInterface.StatusGpio();
            call.enqueue(new Callback<User>() {
                @Override
                public void onResponse(Call<User> call, Response<User> response) {

                    if(response.body().getResponse().equals("ok"))
                    {
                        for(j=0;j<response.body().getBtnStatus().length -1;j++)
                        {
                            if(response.body().getBtnStatus()[j].contains("1"))
                            {
                                arraybuttons[j].setBackgroundTintList(ContextCompat.getColorStateList(getActivity(),R.color.colorApagado));
                            }
                            else
                            {
                                arraybuttons[j].setBackgroundTintList(ContextCompat.getColorStateList(getActivity(),R.color.colorEncendido));
                            }
                        }
                    }
                    else
                    {
                        MainActivity.prefConfig.DisplayToast("Hubo un problema al enviar promoción..");
                    }
                }

                @Override
                public void onFailure(Call<User> call, Throwable t) {

                }
            });
        return view;
    }

}
