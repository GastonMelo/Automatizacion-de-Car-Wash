package com.example.carwashadmin;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import com.google.gson.JsonArray;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * A simple {@link Fragment} subclass.
 */
public class EliminarDescuentoFragment extends Fragment {
    Button ClientesConDescuento,marcartodos,Continuar;
    ListView ClientesListView;
    ArrayList<String[]> arraylistclientes = new ArrayList<String[]>();
    int arraycounter = 0;
    int position_before = -1;
    public EliminarDescuentoFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_eliminar_descuento, container, false);
        Continuar = view.findViewById(R.id.Continuar);
        marcartodos = view.findViewById(R.id.marcartodos);
        ClientesConDescuento = view.findViewById(R.id.clientescondescuento);
        ClientesListView = view.findViewById(R.id.ClientesListView);
        ClientesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                onitemClicked(position);
            }
        });
        ClientesConDescuento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                position_before = -1;
                arraycounter = 0;
                cargarclientes();
            }
        });
        Continuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NotificarClienteEliminarDescuento();
            }
        });
        marcartodos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MarcarTodosClientes();
            }
        });
        return view;
    }

    private void onitemClicked(int position) {
        String[] cliente_cheked = new String[5];
        cliente_cheked = arraylistclientes.get(position);
        if(position_before != position)
        {
            position_before = position;
            cliente_cheked[4] = "true";
        }
        else
        {
            cliente_cheked[5] = "false";
            if(arraycounter == 0)
                position_before = -1;
        }
        arraylistclientes.set(position,cliente_cheked);
        CustomAdapterElimnarDescuento adapterElimnarDescuento = new CustomAdapterElimnarDescuento(getActivity(),-1,arraylistclientes,EliminarDescuentoFragment.this);
        ClientesListView.setAdapter(adapterElimnarDescuento);
    }
    private void MarcarTodosClientes()
    {
        int long_array = arraylistclientes.size();
        for(int x=0;x<long_array;x++)
        {
            String[] check_all = new String[5];
            check_all = arraylistclientes.get(x);
            check_all[4] = "true";
            arraylistclientes.set(x,check_all);
        }
        CustomAdapterElimnarDescuento adapterElimnarDescuento = new CustomAdapterElimnarDescuento(getActivity(),-1,arraylistclientes,EliminarDescuentoFragment.this);
        ClientesListView.setAdapter(adapterElimnarDescuento);
    }
    private void cargarclientes()
    {
        Call<List<clientedescuento>> call = MainActivity.apiInterface.ClientesConDescuentos();
        call.enqueue(new Callback<List<clientedescuento>>() {
            @Override
            public void onResponse(Call<List<clientedescuento>> call, Response<List<clientedescuento>> response) {
                List<clientedescuento> clientedescuentoList = response.body();
                for(int j=0;j<clientedescuentoList.size();j++) {
                    String[] cliente = new String[5];
                    cliente[0] = clientedescuentoList.get(j).getNombre();
                    cliente[1] = clientedescuentoList.get(j).getApellido();
                    cliente[2] = clientedescuentoList.get(j).getDescuento();
                    cliente[3] = clientedescuentoList.get(j).getDni();
                    cliente[4] = ("false");
                    arraylistclientes.add(cliente);
                }
                CustomAdapterElimnarDescuento adapterElimnarDescuento = new CustomAdapterElimnarDescuento(getActivity(),-1,arraylistclientes,EliminarDescuentoFragment.this);
                ClientesListView.setAdapter(adapterElimnarDescuento);
            }

            @Override
            public void onFailure(Call<List<clientedescuento>> call, Throwable t) {

            }
        });
    }

    private void NotificarClienteEliminarDescuento()
    {
        int long_array = arraylistclientes.size();
        for(int i=0;i<long_array;i++)
        {
         String[] cliente = new String[5];
         cliente = arraylistclientes.get(0);
         arraylistclientes.remove(0);
         if(cliente[4] != "false")
         {
             NotificarEliminarDescuento(cliente[3]);
             CustomAdapterElimnarDescuento adapterElimnarDescuento = new CustomAdapterElimnarDescuento(getActivity(),-1,arraylistclientes,EliminarDescuentoFragment.this);
             ClientesListView.setAdapter(adapterElimnarDescuento);
         }
        }
    }
    private void NotificarEliminarDescuento(String clientes_dni)
    {
        Call<User> call = MainActivity.apiInterface.EliminarDescuentoClientes(clientes_dni);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    MainActivity.prefConfig.DisplayToast("Descuento eliminado para clientes seleccionados");
                }
            }
            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }

}
