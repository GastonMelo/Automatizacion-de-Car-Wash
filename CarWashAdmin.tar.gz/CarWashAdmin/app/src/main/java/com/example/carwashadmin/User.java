package com.example.carwashadmin;

import com.google.gson.annotations.SerializedName;


public class User
{
    @SerializedName("response")
    private String Response;

    @SerializedName("creditototal")
    private String[] creditototal;

    @SerializedName("vales")
    private String[] vales;

    @SerializedName("BtnStatus")
    private String[] BtnStatus;

    @SerializedName("NombreApellido")
    private String[] NombreApellido;

    @SerializedName("modelo")
    private String[] modelo;

    @SerializedName("encargado_ventas")
    private String[] encargado_ventas;

    @SerializedName("conteo_limpieza")
    private String[] conteo_limpieza;

    @SerializedName("dni")
    private String dni;

    @SerializedName("nombre_marca")
    private String[] nombre_marca;

    @SerializedName("nombre_categoria")
    private String[] nombre_categoria;

    public String[] getNombre_categoria() {
        return nombre_categoria;
    }

    public String[] getNombre_marca() {
        return nombre_marca;
    }

    public String[] getVales() {
        return vales;
    }

    public String getDni() {
        return dni;
    }

    public String[] getConteo_limpieza() {
        return conteo_limpieza;
    }

    public String[] getEncargado_ventas() {
        return encargado_ventas;
    }

    public String[] getModelo() {
        return modelo;
    }

    public String getResponse()
    {
        return Response;
    }

    public String[] getCreditototal() {
        return creditototal;
    }

    public String[] getBtnStatus() {
        return BtnStatus;
    }

    public String[] getNombreApellido() {
        return NombreApellido;
    }
}
