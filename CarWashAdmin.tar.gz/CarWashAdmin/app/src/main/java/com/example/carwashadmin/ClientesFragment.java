package com.example.carwashadmin;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Lifecycle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.text.SimpleDateFormat;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * A simple {@link Fragment} subclass.
 */
public class ClientesFragment extends Fragment implements CargarCreditoAdmin.SeleccionarDialogListener, HabCompraVales.HabComprarValesListenner {
    private Button EnviarPromocion,EnviarDescuento,EliminarDescuentos, CargarCredito,Estadisticas,hab_compra_vales;
    public String DNI;
    public ClientesFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_clientes, container, false);
        EnviarPromocion = view.findViewById(R.id.EnviarPromocion);
        EnviarDescuento = view.findViewById(R.id.EnviarDescuento);
        CargarCredito = view.findViewById(R.id.CargarCredito);
        Estadisticas = view.findViewById(R.id.Estadisticas);
        hab_compra_vales = view.findViewById(R.id.hab_compra_vales);
        EliminarDescuentos = view.findViewById(R.id.eliminardescuentos);
        EnviarPromocion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.fragmentManager.beginTransaction().replace(R.id.fragment_container, new PromocionFragment(), null).addToBackStack(null).commit();
            }
        });
        EnviarDescuento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.fragmentManager.beginTransaction().replace(R.id.fragment_container, new DescuentoFragment(), null).addToBackStack(null).commit();
            }
        });
        EliminarDescuentos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.fragmentManager.beginTransaction().replace(R.id.fragment_container, new EliminarDescuentoFragment(), null).addToBackStack(null).commit();
            }
        });
        CargarCredito.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CargarCreditoAdmin cargarCreditoAdmin = new CargarCreditoAdmin();
                cargarCreditoAdmin.setTargetFragment(ClientesFragment.this,1);
                cargarCreditoAdmin.setCancelable(false);
                cargarCreditoAdmin.show(getFragmentManager(),null);
            }
        });
        hab_compra_vales.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HabCompraVales habCompraVales = new HabCompraVales();
                habCompraVales.setTargetFragment(ClientesFragment.this,1);
                habCompraVales.setCancelable(false);
                habCompraVales.show(getFragmentManager(),null);
            }
        });
        return view;
    }

    @Override
    public void NombreApellido(String nombre, String apellido,String credito) {
        final String nombre_apellido_cliente = nombre + " " + apellido;
        final String importe_cargar = credito;
        Date now = new Date();
        String fecha = new SimpleDateFormat("yyyy-MM-dd").format(now);
        Call<User> call = MainActivity.apiInterface.CargaCreditoNA(nombre,apellido,credito,fecha);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    DNI = response.body().getDni();
                    enviar_notificacion_cliente(DNI,importe_cargar);
                    MainActivity.prefConfig.DisplayToast("Carga realizada a: " + nombre_apellido_cliente);
                }
            }
            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }

    /********************************************************************************/
    /*                      enviar_notificacion_cliente                            */
    /********************************************************************************/
    private void enviar_notificacion_cliente(String dni, String importe_carga)
    {
        String title="Recarga";
        String message= "Carga de credito registrada";
        String data = "CargaCredito_" + importe_carga;
        Call<User> call = MainActivity.apiInterface.SendNotification(dni,title,message,data);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {

                }
            }
            @Override
            public void onFailure(Call<User> call, Throwable t) {
            }
        });
    }
}
