package com.example.carwashadmin;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.text.SimpleDateFormat;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * A simple {@link Fragment} subclass.
 */
public class DescuentoFragment extends Fragment implements NombreApellidoDialog.SeleccionarDialogListener{

    private EditText TituloDescuento, MensajeDescuento,DescuentoText;
    private RadioGroup DEscuentoRG;
    private RadioButton Fem_RB,Masc_RB,Todos_RB;
    private Button BuscarDestinatario,EnviarDescuento;
    public String ParametroDescuento,porcentaje_descuento,nombre,apellido,modelo_vehiculo;
    public String Busqueda = "default";


    public DescuentoFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_descuento, container, false);
        TituloDescuento = view.findViewById(R.id.TituloDescuento);
        MensajeDescuento = view.findViewById(R.id.MensajeDescuento);
        DescuentoText = view.findViewById(R.id.Descuentotxt);
        DEscuentoRG = view.findViewById(R.id.radio_group_descuento);
        Fem_RB = view.findViewById(R.id.descuento_femenino);
        Masc_RB = view.findViewById(R.id.descuento_masculinos);
        Todos_RB = view.findViewById(R.id.descuentos_todos);
        BuscarDestinatario = view.findViewById(R.id.descuento_buscar);
        EnviarDescuento = view.findViewById(R.id.EnviarDescuento);
        DEscuentoRG.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId)
                {
                    case R.id.descuento_femenino:
                        ParametroDescuento = "F";
                        break;
                    case R.id.descuento_masculinos:
                        ParametroDescuento = "M";
                    case R.id.descuentos_todos:
                        ParametroDescuento = "T";
                        break;
                }
            }
        });
        BuscarDestinatario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AbrirDialogoBusqueda();
            }
        });
        EnviarDescuento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                porcentaje_descuento = DescuentoText.getText().toString();
                switch(Busqueda)
                {
                    case "individual":
                    {
                        EnviarDescuentoIndividual();
                        break;
                    }
                    case "vehicular":
                    {
                        NotificarPorVehiculo();
                        break;
                    }
                    default:
                    {
                        EnviarDescuentoMasivo();
                        break;
                    }
                }
            }
        });
        return view;
    }

    public void AbrirDialogoBusqueda()
    {
        NombreApellidoDialog nombreApellidoDialog = new NombreApellidoDialog();
        //realizar esto al enviar datos del fragmento NombreApellidoDialog al fragmento PromocionFragment
        //y en NombreApellidoDialog se especifica en onattach se incluye setTargetFragment en lugar de "context"
        nombreApellidoDialog.setTargetFragment(DescuentoFragment.this,1);
        nombreApellidoDialog.show(getFragmentManager(), "Seleccionar Usuario");
    }

    private void NotificarPorVehiculo()
    {
        String titulo = TituloDescuento.getText().toString();
        String mensaje = MensajeDescuento.getText().toString();
        String vehiculo_usuario = modelo_vehiculo;
        String descuento = "Descuento_" + DescuentoText.getText().toString();
        Call<User> call = MainActivity.apiInterface.NotificarPorVehiculo(titulo,mensaje,descuento,vehiculo_usuario);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {

                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
        TituloDescuento.setText("");
        MensajeDescuento.setText("");
        DescuentoText.setText("");
    }

    private void EnviarDescuentoIndividual()
    {
        Date now = new Date();
        final String fecha = new SimpleDateFormat("yyyy-MM-dd").format(now);
        final String porcentaje_descuento = DescuentoText.getText().toString();
        String descuento = "Descuento_" + porcentaje_descuento;
        Call<User> call = MainActivity.apiInterface.IndividualNotification(TituloDescuento.getText().toString(),MensajeDescuento.getText().toString(),descuento,nombre,apellido);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    MainActivity.prefConfig.DisplayToast("Descuento enviado a: " + nombre + apellido);
                    registrardescuentoindividual(nombre,apellido,porcentaje_descuento,fecha);
                }
                else
                {
                    MainActivity.prefConfig.DisplayToast("Surgio un problema al enviar promoción : " + nombre + apellido);
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
        TituloDescuento.setText("");
        MensajeDescuento.setText("");
        DescuentoText.setText("");
    }

    /**************************************************************************************************************************************************************************/
    /**                                                         registrar descuento individual                                                                              ***/
    /**************************************************************************************************************************************************************************/
    private void registrardescuentoindividual(String nombre, String apellido,String descuento,String fecha)
    {
        Call<User> call = MainActivity.apiInterface.DescuentoIndividual(nombre,apellido,descuento,fecha);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    MainActivity.prefConfig.DisplayToast("Descuento registrado en base de datos...");
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }
    /**************************************************************************************************************************************************************************/
    private void EnviarDescuentoMasivo()
    {
        final String destinatarios = ParametroDescuento;
        final String porcentaje_descuento = DescuentoText.getText().toString();
        String descuento = "Descuento_" + porcentaje_descuento;
        Date now = new Date();
        final String fecha = new SimpleDateFormat("yyyy-MM-dd").format(now);
        Call<User> call = MainActivity.apiInterface.SendNotificationUsers(TituloDescuento.getText().toString(), MensajeDescuento.getText().toString(), descuento, destinatarios);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    MainActivity.prefConfig.DisplayToast("Descuento enviada");
                    registrardescuentomasivo(porcentaje_descuento,fecha,destinatarios);
                }
                else
                {
                    MainActivity.prefConfig.DisplayToast("Surgio un problema al enviar promoción..");
                }
            }
            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
        ParametroDescuento="";
        TituloDescuento.setText("");
        MensajeDescuento.setText("");
        DescuentoText.setText("");
    }
    /**************************************************************************************************************************************************************************/
    /**                                                         registrar descuento masivo                                                                                  ***/
    /**************************************************************************************************************************************************************************/
    private void registrardescuentomasivo(String descuento,String fecha,String destinatarios)
    {
        Call<User> call = MainActivity.apiInterface.DescuentoMasivo(descuento,fecha,destinatarios);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    MainActivity.prefConfig.DisplayToast("Descuento registrado en base de datos...");
                }
            }
            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }
    /**************************************************************************************************************************************************************************/
    @Override
    public void NombreApellido(String nombre_busqueda, String apellido_busqueda) {
        nombre = nombre_busqueda;
        apellido = apellido_busqueda;
        Busqueda = "individual";
    }

    @Override
    public void ModeloVehiculo(String modelo) {
        Busqueda = "vehicular";
        modelo_vehiculo = modelo;
    }
}
