package com.example.carwashadmin;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.ContentValues.TAG;

public class cargarproductosqrstock extends AppCompatDialogFragment {
    AlertDialog alertDialog;
    Button Continuar,Cancelar;
    EditText descripciontxt,cantidadtxt,preciounitariotxt,codigotxt,unidadestxt;
    private CargarProductoStock cargarProductoStock;
    public interface CargarProductoStock
    {

    }
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.cargarproductoqrstock,null);
        descripciontxt = view.findViewById(R.id.descripciontxt);
        cantidadtxt = view.findViewById(R.id.cantidadtxt);
        preciounitariotxt = view.findViewById(R.id.preciounitariotxt);
        codigotxt = view.findViewById(R.id.codigotxt);
        unidadestxt = view.findViewById(R.id.unidadestxt);
        Continuar = view.findViewById(R.id.Continuar);
        Cancelar = view.findViewById(R.id.Cancelar);
        Bundle args = getArguments();
        String aux1 = args.getString("descripcion");
        descripciontxt.setText(aux1);
        String aux2 = args.getString("cantidad");
        cantidadtxt.setText(aux2);
        String aux3 = args.getString("preciounitario");
        preciounitariotxt.setText(aux3);
        String aux4 = args.getString("codigo");
        codigotxt.setText(aux4);
        Continuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegistrarProductoStock();
                getDialog().dismiss();
            }
        });
        Cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getDialog().dismiss();
            }
        });
        builder.setView(view);
        alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        return alertDialog;
    }
    private void RegistrarProductoStock()
    {
        int cantidad = Integer.parseInt(unidadestxt.getText().toString());
        String codigo = codigotxt.getText().toString();
        Call<User> call = MainActivity.apiInterface.AgregarProductoQrStock(cantidad,codigo);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    MainActivity.prefConfig.DisplayToast("nuevo ingreso registrado..");
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });

    }
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            cargarProductoStock = (CargarProductoStock) getTargetFragment();
        }catch (ClassCastException e)
        {
            Log.e(TAG, "ClassCastException: " + e.getMessage());
        }
    }
}
