package com.example.carwashadmin;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * A simple {@link Fragment} subclass.
 */
public class PromocionFragment extends Fragment implements NombreApellidoDialog.SeleccionarDialogListener {

    private EditText TituloNotificacion, MensajeNotificacion;
    public String ParametroEnviarNotificacion;
    public String nombre, apellido,data,modelo_vehiculo;
    private Button SendNotification,SeleccionarUsuario;
    public String busqueda = "default";
    private RadioGroup NotificacionRadioGroup;
    private RadioButton NotificacionTodos, Notificacion_F, Notificacion_M;

    public PromocionFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_enviar, container, false);
        //evitar enviar nulos a usuario
        data = "Promocion_0";
        TituloNotificacion = view.findViewById(R.id.Titulo_Notificación);
        MensajeNotificacion = view.findViewById(R.id.Mensaje_Notificación);
        SendNotification = view.findViewById(R.id.EnviarNotificacionUsuarios);
        SendNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (busqueda) {
                    case "individual":
                        {
                            notificacion_individual();
                            break;
                        }
                    case "vehicular":
                        {
                            NotificarPorVehiculo();
                            break;
                        }
                    default:
                        {
                            SendNotification();
                            break;
                        }
                }
            }
        });
        SeleccionarUsuario = view.findViewById(R.id.SeleccionarUsuario);
        SeleccionarUsuario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BusquedaNombreApellido();
            }
        });
        Notificacion_F = view.findViewById(R.id.radio_button_Femeninos);
        Notificacion_M = view.findViewById(R.id.radio_button_Masculinos);
        NotificacionTodos = view.findViewById(R.id.Radio_button_todos);
        NotificacionRadioGroup = view.findViewById(R.id.NotificacionRadioGroup);
        NotificacionRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId)
                {
                    case R.id.radio_button_Femeninos:
                        ParametroEnviarNotificacion="F";
                        break;

                    case R.id.radio_button_Masculinos:
                        ParametroEnviarNotificacion="M";
                        break;
                    case R.id.Radio_button_todos:
                        ParametroEnviarNotificacion="T";
                        break;
                }
            }
        });
        return view;
    }

    public void BusquedaNombreApellido()
    {
        NombreApellidoDialog nombreApellidoDialog = new NombreApellidoDialog();
        //realizar esto al enviar datos del fragmento NombreApellidoDialog al fragmento PromocionFragment
        //y en NombreApellidoDialog se especifica en onattach se incluye setTargetFragment en lugar de "context"
        nombreApellidoDialog.setTargetFragment(PromocionFragment.this,1);
        nombreApellidoDialog.show(getFragmentManager(), "Seleccionar Usuario");
    }

    private void NotificarPorVehiculo()
    {
        String titulo = TituloNotificacion.getText().toString();
        String mensaje = MensajeNotificacion.getText().toString();
        String vehiculo_usuario = modelo_vehiculo;
        Call<User> call = MainActivity.apiInterface.NotificarPorVehiculo(titulo,mensaje,data,vehiculo_usuario);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {

                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
        TituloNotificacion.setText("");
        MensajeNotificacion.setText("");
    }

    private void SendNotification()
    {
        String destinatarios = ParametroEnviarNotificacion;
        String titulo = TituloNotificacion.getText().toString();
        String mensaje = MensajeNotificacion.getText().toString();
        Call<User> call = MainActivity.apiInterface.SendNotificationUsers(titulo, mensaje, data, destinatarios);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {

                if(response.body().getResponse().equals("ok"))
                {
                    MainActivity.prefConfig.DisplayToast("Promoción enviada");
                }
                else
                {
                    MainActivity.prefConfig.DisplayToast("Surgio un problema al enviar promoción..");
                }

            }
            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
        TituloNotificacion.setText("");
        MensajeNotificacion.setText("");
    }

    private void notificacion_individual()
    {
        String titulo = TituloNotificacion.getText().toString();
        String mensaje = MensajeNotificacion.getText().toString();
        Call<User> call = MainActivity.apiInterface.IndividualNotification(titulo,mensaje, data, nombre,apellido);
        call.enqueue(new Callback<User>() {

            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    MainActivity.prefConfig.DisplayToast("Promoción enviada a: " + nombre + "" + apellido);
                }
                else
                {
                    MainActivity.prefConfig.DisplayToast("Surgio un problema al enviar promoción : " + nombre + "" + apellido);
                }
            }
            @Override
            public void onFailure(Call<User> call, Throwable t) {
            }
        });
        TituloNotificacion.setText("");
        MensajeNotificacion.setText("");
    }


    @Override
    public void NombreApellido(String nombre_busqueda, String apellido_busqueda) {
        nombre = nombre_busqueda;
        apellido = apellido_busqueda;
        busqueda = "individual";
    }

    @Override
    public void ModeloVehiculo(String modelo)
    {
        busqueda = "vehicular";
        modelo_vehiculo = modelo;
    }
}
