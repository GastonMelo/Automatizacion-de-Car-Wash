package com.example.carwashadmin;

import androidx.annotation.InspectableProperty;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface
{
    @GET("notificaciones.php")
    Call<User> SendNotificationUsers(@Query("titulo") String Titulo,@Query("mensaje") String Mensaje,@Query("data") String Data, @Query("destinatarios") String Destinatarios);
    @GET("notificacion_individual.php")
    Call<User> IndividualNotification(@Query("titulo") String Titulo,@Query("mensaje") String Mensaje,@Query("data") String Data, @Query("nombre") String Nombre,@Query("apellido") String Apellido);
    @GET("obtenercargascredito.php")
    Call<User> CargasdeCreditoFecha(@Query("fecha") String FechaConsulta);
    @GET("obtenercargasvales.php")
    Call<User> CargasdeValesFecha(@Query("fecha") String FechaConsulta);
    @GET("nuevovalorficha.php")
    Call<User> NuevoValorFicha(@Query("valorficha") String ValorFicha);
    @GET("btn_status.php")
    Call<User> StatusGpio();
    @GET("autocompletar_nombre.php")
    Call<User> AutoCompletarNombre(@Query("id") String NameUser);
    @GET("autocompletar_vehiculo.php")
    Call<User> AutoCompletarVehiculo(@Query("id") String ModeloVehiculo);
    @GET("notificar_por_vehiculo.php")
    Call<User> NotificarPorVehiculo(@Query("titulo") String Titulo, @Query("mensaje") String Mensaje,@Query("data") String Data, @Query("modelo") String Modelo);
    @GET("control_limpieza.php")
    Call<User> ControlLimpieza(@Query("datetime") String DateTime);
    @GET("cargarcreditoNA.php")
    Call<User> CargaCreditoNA(@Query("nombre") String Nombre, @Query("apellido") String Apellido, @Query("credito") String Credito, @Query("fecha") String Fecha);
    @GET("notificar_cargacredito.php")
    Call<User> SendNotification(@Query("dni") String DNI, @Query("title") String Title, @Query("message") String Message, @Query("data") String Data);
    @GET("descuentoindividual.php")
    Call<User> DescuentoIndividual(@Query("nombre") String Nombre,@Query("apellido") String Apellido,@Query("descuento") String descuento,@Query("fecha") String Fecha);
    @GET("descuentomasivo.php")
    Call<User> DescuentoMasivo(@Query("descuento") String descuento,@Query("fecha") String Fecha,@Query("destinatarios") String Destinatarios);
    @GET("habclientevale.php")
    Call<User> HabClienteVale(@Query("nombre") String Nombre,@Query("apellido") String Apellido,@Query("enable") String Enable);
    @GET("cargarcatalogo.php")
    Call<List<catalogo>> cargarcatalogo();
    @GET("cargarmarca.php")
    Call<List<marca>> cargarmarca();
    @GET("cargarcategoria.php")
    Call<List<categoria>> cargarcategoria();
    @GET("cargarcategoriaitem.php")
    Call<List<catalogo>> CargarCategoriaItem(@Query("categoria_item") String CategoriaItem);
    @GET("cargarmarcaitem.php")
    Call<List<catalogo>> CargarMarcaItem(@Query("marca_item") String MarcaItem);
    @GET("modificaritemstock.php")
    Call<User> ModificarItemStock(@Query("descripcion") String Descripcion,@Query("cantidad") int Cantidad,@Query("preciounitario") int PrecioUnitario,@Query("codigo") String Codigo);
    @GET("editarmarca.php")
    Call<User> EditarPUMarca(@Query("marca") String Marca,@Query("interes") int Interes,@Query("descuento") int Descuento);
    @GET("editarcategoria.php")
    Call<User> EditarPÜCategoria(@Query("categoria") String Categoria,@Query("interes") int Interes,@Query("descuento") int Descuento);
    @GET("eliminaritemstock.php")
    Call<User> ElimnarItemStock(@Query("categoria") String ItemStock);
    @GET("eliminaritemstockm.php")
    Call<User> EliminarItemStockM(@Query("marca") String ItemStock);
    @GET("eliminarproductostock.php")
    Call<User> EliminarProductoStock(@Query("codigo") String Codigo);
    @GET("agregarcategoria.php")
    Call<User> AgregarCategoria(@Query("nombre") String Nombre);
    @GET("agregarmarca.php")
    Call<User> AgregarMarca(@Query("nombre") String Marca);
    @GET("buscarstockporcodigo.php")
    Call<List<catalogo>> BuscarStockCodigo(@Query("codigo") String Codigo);
    @GET("agregarproductoqrstock.php")
    Call<User> AgregarProductoQrStock(@Query("cantidad") int Cantidad,@Query("codigo") String Codigo);
    @GET("agregarproductonuevostock.php")
    Call<User> AgregarProductoNuevoStock(@Query("preciounitario") int PrecioUnitario,@Query("cantidad") int Cantidad,@Query("descripcion") String Descripcion,@Query("codigo") String Codigo,@Query("categoria") String Categoria,@Query("marca") String Marca);
    @GET("autocompletar_marca.php")
    Call<User> AutocompletarMarca(@Query("id") String Id);
    @GET("autocompletar_categoria.php")
    Call<User> AutocompletarCategoria(@Query("id") String Id);
    @GET("venderproductostock.php")
    Call<User> VenderProductoStock(@Query("cantidad") int Cantidad,@Query("codigo") String Codigo,@Query("vendedor") String Vendedor);
    @GET("eliminardescuentosclientes.php")
    Call<List<clientedescuento>> ClientesConDescuentos();
    @GET("notificareliminardescuentos.php")
    Call<User> EliminarDescuentoClientes(@Query("clientes_dni") String DniClientes);
}
