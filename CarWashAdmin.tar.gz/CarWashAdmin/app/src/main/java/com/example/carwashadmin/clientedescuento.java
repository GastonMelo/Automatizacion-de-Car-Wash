package com.example.carwashadmin;

public class clientedescuento {
    private String nombre;
    private String apellido;
    private String dni;
    private String descuento;
    public clientedescuento(String nombre,String apellido,String dni,String descuento)
    {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.descuento = descuento;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getDni() {
        return dni;
    }

    public String getDescuento() {
        return descuento;
    }
}
