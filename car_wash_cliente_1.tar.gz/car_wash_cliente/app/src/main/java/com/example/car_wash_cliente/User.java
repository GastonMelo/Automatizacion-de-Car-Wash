package com.example.car_wash_cliente;

import com.google.gson.annotations.SerializedName;

public class User {
    @SerializedName("response")
    private String Response;

    @SerializedName("nombre")
    private String Name;

    @SerializedName("credito")
    private String Credito;

    @SerializedName("valor_ficha")
    private String ValorFicha;

    @SerializedName("fichas_restantes")
    private String fichas_restantes;

    @SerializedName("descuento")
    private String descuento;

    public String getName() {
        return Name;
    }

    public String getResponse() {
        return Response;
    }

    public String getCredito() {
        return Credito;
    }

    public String getValorFicha() {
        return ValorFicha;
    }

    public String getFichas_restantes() {
        return fichas_restantes;
    }

    public String getDescuento() {
        return descuento;
    }
}
