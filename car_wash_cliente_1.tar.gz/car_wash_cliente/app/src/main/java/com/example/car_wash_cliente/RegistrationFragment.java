package com.example.car_wash_cliente;

import android.app.DatePickerDialog;
import android.os.Build;
import android.os.Bundle;

import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.car_wash_cliente.MainActivity.prefConfig;
import static com.example.car_wash_cliente.PrefConfig.NameStringXML;
import static com.example.car_wash_cliente.PrefConfig.Payer_Email;
import static com.example.car_wash_cliente.PrefConfig.Payerlastname;
import static com.example.car_wash_cliente.PrefConfig.UserIDXML;
import static com.example.car_wash_cliente.PrefConfig.UserToken;


/**
 * A simple {@link Fragment} subclass.
 */
public class RegistrationFragment extends Fragment implements DatePickerFragment.DateListenner {

    public EditText Nombre,Apellido, DNI, DireccionCorreo, Clave, ModeloVehiculo;
    public String nombre,dni;
    private Button FechaNac;
    public String FechaNacimiento;
    String genero = "F";
    private RadioGroup GeneroUsuario;
    private RadioButton GeneroFemenino, GeneroMasculino;
    private Button BtnRegister;
    public RegistrationFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_registration, container, false);
        ((MainActivity)getActivity()).getSupportActionBar().setTitle("Registrarse");
        Nombre = view.findViewById(R.id.nombre);
        Apellido = view.findViewById(R.id.apellido);
        DNI = view.findViewById(R.id.dni);
        FechaNac = view.findViewById(R.id.fecha_nacimiento);
        GeneroUsuario = view.findViewById(R.id.genero_usuario);
        GeneroFemenino = view.findViewById(R.id.Femenino);
        GeneroMasculino = view.findViewById(R.id.Masculino);
        GeneroUsuario.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId)
                {
                    case R.id.Masculino:
                        genero="M";
                        break;
                    case R.id.Femenino:
                        genero="F";
                        break;
                }
            }
        });
        ModeloVehiculo = view.findViewById(R.id.ModeloVehiculo);
        DireccionCorreo = view.findViewById(R.id.direccion_correo);
        Clave = view.findViewById(R.id.clave);
        BtnRegister = view.findViewById(R.id.btn_registrarse);
        BtnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                performRegistration();
            }
        });
        FechaNac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment dialogFragment = new DatePickerFragment();
                dialogFragment.setTargetFragment(RegistrationFragment.this,1);
                dialogFragment.show(getFragmentManager(),"seleccionar fecha");
            }
        });
        return view;
    }
    /********************************************************************************/
    /*                      REGISTRA USUARIO                                        */
    /********************************************************************************/
    public void performRegistration()
    {

        nombre = Nombre.getText().toString();
        String apellido = Apellido.getText().toString();
        prefConfig.Write(Payerlastname,apellido);
        dni = DNI.getText().toString();
        String fecha_nac = FechaNacimiento;
        String modelo_vehiculo = ModeloVehiculo.getText().toString();
        String direccion_correo = DireccionCorreo.getText().toString();
        prefConfig.Write(Payer_Email,direccion_correo);
        String clave = Clave.getText().toString();
        String Token = prefConfig.Read(UserToken);
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        int version = Build.VERSION.SDK_INT;
        String versionRelease = Build.VERSION.RELEASE;
        Call<User> call = MainActivity.apiInterface.performRegistration(dni,nombre,apellido,fecha_nac,genero,modelo_vehiculo,direccion_correo,clave,manufacturer,model,version,versionRelease,Token);

        call.enqueue(new Callback<User>()
        {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    prefConfig.DisplayToast("Registration Success...");
                    prefConfig.WriteLoginStatus(true);
                    prefConfig.Write(UserIDXML, dni);
                    prefConfig.Write(NameStringXML, nombre);
                    ((MainActivity)getActivity()).performLogin(nombre);
                }
                else if(response.body().getResponse().equals("exist"))
                {
                    prefConfig.DisplayToast("User already exist...");
                }
                else if(response.body().getResponse().equals("error"))
                {
                    prefConfig.DisplayToast("Something went wrong...");
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
        Nombre.setText("");
        Apellido.setText("");
        DNI.setText("");
        ModeloVehiculo.setText("");
        DireccionCorreo.setText("");
        Clave.setText("");
        FechaNac.setText("FECHA NACIMIENTO DIA/MES/AÑO");
    }

    @Override
    public void DateCalendar(String fecha) {
        FechaNacimiento = fecha;
        FechaNac.setText(FechaNacimiento);
    }
}
