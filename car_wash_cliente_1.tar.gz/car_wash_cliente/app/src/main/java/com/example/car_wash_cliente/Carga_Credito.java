package com.example.car_wash_cliente;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Carga_Credito extends AppCompatActivity {
    private Button Continuar;
    private TextView CargaTxT;
    public String msg;
    public interface OnCargaCreditoListener
    {
        void ReadCreditClient();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        msg = getIntent().getStringExtra("Extra");
        setContentView(R.layout.activity_carga__credito);
        CargaTxT = findViewById(R.id.CargaCreditotxt);
        CargaTxT.setText("Carga realizada de: $" + msg);
        Continuar = (Button) findViewById(R.id.Aceptar);
        Continuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                Intent intent = new Intent(Carga_Credito.this,MainActivity.class);
                startActivity(intent);
            }
        });

    }
}
