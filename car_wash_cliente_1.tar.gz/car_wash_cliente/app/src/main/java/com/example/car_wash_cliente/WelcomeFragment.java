package com.example.car_wash_cliente;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.car_wash_cliente.PrefConfig.NameStringXML;
import static com.example.car_wash_cliente.PrefConfig.UserIDXML;
import static com.example.car_wash_cliente.PrefConfig.UserToken;


/**
 * A simple {@link Fragment} subclass.
 */
public class WelcomeFragment extends Fragment implements dialog_qr.QrDialogListenner, dialog_comprastock.QRCompraStockListenner{
    private Button btncredit,facebook,whatsapp,instagram;
    public String FuncionQr,ValorFichaActual = "0",clientcredit = "0",DescuentoActual = "0",FichasVale="0",valoractual="0";
    public String codigo_producto;
    OnLogoutListener logoutListener;
    static MenuItem ficha_value, credito_cliente,fichas_vale;

    public static WelcomeFragment instance = null;



    public interface OnLogoutListener
    {
        public void logoutperformed();
    }
    public WelcomeFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;
    }

    public static  WelcomeFragment getInstance() {
        return instance;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //LocalBroadcastManager.getInstance(getContext()).registerReceiver(
        //        mMessageReceiver, new IntentFilter("carga_credito"));

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_welcome, container, false);

        ImageView DNIQR = view.findViewById(R.id.DNIQR);
        String DNI_QR = MainActivity.prefConfig.Read(UserIDXML);
        MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
        try{
            Map<EncodeHintType, Object> hintMap = new EnumMap<EncodeHintType, Object>(EncodeHintType.class);
            hintMap.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            hintMap.put(EncodeHintType.MARGIN, 1);
            hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
            BitMatrix bitMatrix = multiFormatWriter.encode(DNI_QR, BarcodeFormat.QR_CODE,200,200,hintMap);
            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);
            DNIQR.setImageBitmap(bitmap);
        }catch (WriterException e){

        }
        setHasOptionsMenu(true);
        ((MainActivity)getActivity()).getSupportActionBar().setTitle(MainActivity.prefConfig.Read(NameStringXML));
        facebook = view.findViewById(R.id.Facebook);
        whatsapp = view.findViewById(R.id.Whatsapp);
        instagram = view.findViewById(R.id.Instagram);
        btncredit = view.findViewById(R.id.btn_credito);
        btncredit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                IntentIntegrator vistaescanner = IntentIntegrator.forSupportFragment(WelcomeFragment.this);
                vistaescanner.setPrompt("Scan");
                vistaescanner.setBeepEnabled(true);
                vistaescanner.setOrientationLocked(true);
                vistaescanner.setCaptureActivity(CaptureActivityPortrait.class);
                vistaescanner.initiateScan();
            }
        });
        facebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotofacebook("197623960369434");
            }
        });
        whatsapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotowhatsapp();
            }
        });
        instagram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoinstagram();
            }
        });
        /********************************************************************************/
        /*                      UPGRADE VALUES FROM DATABASE                            */
        /********************************************************************************/
        VariablesAjuste();
        SendToken();
        /********************************************************************************/
        /*                                                                              */
        /********************************************************************************/
        return view;
    }

    private void gotoinstagram()
    {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://instagram.com/_u/007CARWASH/"));
            startActivity(intent);
        }catch (ActivityNotFoundException e){
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/USER/007CARWASH"));
            startActivity(intent);
        }
    }

    private void gotowhatsapp()
    {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=+5492994099153"));
            startActivity(intent);
        }catch (ActivityNotFoundException e){
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/"));
            startActivity(intent);
        }
    }

    private void gotofacebook(String id)
    {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("fb://page/" + id));
            startActivity(intent);
        }catch (ActivityNotFoundException e){
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/"));
            startActivity(intent);
        }
    }
    /********************************************************************************/
    /*                      INCLUYE MENU USUARIO EN TASKBAR                         */
    /********************************************************************************/

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflator) {
        inflator.inflate(R.menu.menu_main, menu);
        ficha_value = menu.findItem(R.id.ficha_valor);
        credito_cliente = menu.findItem(R.id.creditocliente);
        fichas_vale = menu.findItem(R.id.fichas_vale);
        ficha_value.setTitle("$" + ValorFichaActual);
        credito_cliente.setTitle("$" + clientcredit);
        fichas_vale.setTitle(FichasVale);
        return;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.Logout)
        {
            logoutListener.logoutperformed();
        }
        if(item.getItemId() == R.id.About)
        {
            Intent intent = new Intent(getActivity(),about_me.class);
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }
    /********************************************************************************/
    /*                      QR scan resultado                                       */
    /********************************************************************************/
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        IntentResult scan_result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if(scan_result.getContents() != null)
        {
            FuncionQr = scan_result.getContents();
            if(FuncionQr.contains("hidrolavadaora") || FuncionQr.contains("aspiradora"))
                dialog_qr();
            else
                SearchForCode(FuncionQr);
        }
    }
    private void SearchForCode(final String codigo)
    {
        Call<List<catalogo>> call = MainActivity.apiInterface.BuscarStockCodigo(codigo);
        call.enqueue(new Callback<List<catalogo>>() {
            @Override
            public void onResponse(Call<List<catalogo>> call, Response<List<catalogo>> response) {
                List<catalogo> catalogoList = response.body();
                if(catalogoList.get(0).getStatus().equals("ok"))
                {
                    String descripcion = catalogoList.get(0).getDescripcion();
                    String cantidad = catalogoList.get(0).getCantidad();
                    String preciounitario = catalogoList.get(0).getPrecio_unitario();
                    codigo_producto = catalogoList.get(0).getCodigo();
                    if(DescuentoActual != "0")
                    {
                        int Descuento_Cliente = Integer.parseInt(DescuentoActual);
                        int precio_a_cobrar = Integer.parseInt(preciounitario);
                        int precio_descuento = precio_a_cobrar - ((precio_a_cobrar*Descuento_Cliente)/100);
                        preciounitario = String.valueOf(precio_descuento);
                    }
                    dialog_comprastock(descripcion,cantidad,preciounitario,codigo_producto);
                }
            }

            @Override
            public void onFailure(Call<List<catalogo>> call, Throwable t) {

            }
        });
    }
    @Override
    public void OnClickOK() {
        if(FichasVale.equals("0")) {
            performOperation();
        }
        else
        {
            ConsumirFichaVale();
        }
    }

    @Override
    public void QRCompraAceptada(int precio_total,int unidades_vendidas,String descripcionproducto) {
        int credito_cliente = Integer.parseInt(clientcredit);
        if(precio_total > credito_cliente)
        {
            MainActivity.prefConfig.DisplayToast("No dispone de credito suficiente");
        }
        else
        {
            UpdateClientCredit(precio_total,unidades_vendidas,descripcionproducto);
        }
    }
    private void UpdateClientCredit(int importe_compra,final int unidades,final String descripcion)
    {
        String dni = MainActivity.prefConfig.Read(UserIDXML);
        Date now = new Date();
        String fecha = new SimpleDateFormat("yyyy-MM-dd").format(now);
        Call<User> call = MainActivity.apiInterface.ClienteComproProducto(dni,importe_compra,fecha,unidades,codigo_producto);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    MainActivity.prefConfig.DisplayToast("Ud. realizo una compra de productos");
                    dialog_ok(descripcion,unidades);
                    VariablesAjuste();
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }
    /********************************************************************************/
    /*                      ACTUALIZA VALOR DE TOKEN                                */
    /********************************************************************************/
    public void SendToken()
    {
        String dni = MainActivity.prefConfig.Read(UserIDXML);
        String Token = MainActivity.prefConfig.Read(UserToken);
        Call<User> call = MainActivity.apiInterface.SendToken(dni,Token);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response)
            {
                if(response.body().getResponse().equals("ok"))
                {
                    //MainActivity.prefConfig.DisplayToast("token registrado");
                }
            }
            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }

    public void VariablesAjuste()
    {
        String dni = MainActivity.prefConfig.Read(UserIDXML);
        Call<User> call = MainActivity.apiInterface.VariablesAjuste(dni);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    valoractual = response.body().getValorFicha();
                    DescuentoActual = response.body().getDescuento();
                    clientcredit = response.body().getCredito();
                    String auxiliar = response.body().getFichas_restantes();
                    if(auxiliar.equals("0"))
                    {
                        FichasVale = response.body().getFichas_restantes();
                        //DescuentoActual = "0";
                    }
                    else
                    {
                        FichasVale = response.body().getFichas_restantes();
                        DescuentoActual = "10";
                    }
                    Integer valorfichahoy = Integer.parseInt(valoractual);
                    Integer descuentocliente = Integer.parseInt(DescuentoActual);
                    Integer descuentohoy = (valorfichahoy*descuentocliente)/100;
                    Integer coinvalue = valorfichahoy - descuentohoy;
                    ValorFichaActual = String.valueOf(coinvalue);
                    getActivity().invalidateOptionsMenu();
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }
    /********************************************************************************/
    /*                      ACTIVA HIDRO O ASPIRADORA POR FICHA                     */
    /********************************************************************************/
    public void performOperation()
    {
        String dni = MainActivity.prefConfig.Read(UserIDXML);
        Date now = new Date();
        String fecha = new SimpleDateFormat("yyyy-MM-dd").format(now);
        String valor_ficha = ValorFichaActual;
        Call<User> call = MainActivity.apiInterface.performOperation(dni,valor_ficha,fecha);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    VariablesAjuste();
                    habilitarGpio(FuncionQr);
                }
                else
                {
                    dialog_error();
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }
    /********************************************************************************/
    /*                      ACTIVA HIDRO O ASPIRADORA POR VALE                      */
    /********************************************************************************/
    public void ConsumirFichaVale()
    {
        String dni = MainActivity.prefConfig.Read(UserIDXML);
        Date now = new Date();
        String fecha = new SimpleDateFormat("yyyy-MM-dd").format(now);
        Call<User> call = MainActivity.apiInterface.ConsumirFichaVale(dni,fecha);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {
                    VariablesAjuste();
                    habilitarGpio(FuncionQr);
                }
                else
                {
                    dialog_error();
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }
    /********************************************************************************/
    /*                      ACTIVA GPIOS DE RASPBERRY                               */
    /********************************************************************************/
    public void habilitarGpio(String Funcion_usando)
    {
        String gpio = "0";

        switch (Funcion_usando)
        {
            case "hidrolavadora_1":
                gpio = "0";
                break;

            case "hidrolavadora_2":
                gpio = "1";
                break;

            case "hidrolavadora_3":
                gpio = "2";
                break;

            case "hidrolavadora_4":
                gpio = "3";
                break;

            case "aspiradora_1":
                gpio = "4";
                break;
            case "aspiradora_2":
                gpio = "5";
                break;

            case "aspiradora_3":
                gpio = "6";
                break;

            case "aspiradora_4":
                gpio = "7";
                break;
        }
        Call<User> call = MainActivity.apiInterface.activategpio(gpio);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.body().getResponse().equals("ok"))
                {

                }
                else
                {
                    dialog_error();
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        Activity activity = (Activity) context;
        logoutListener = (OnLogoutListener) activity;
    }
    private void dialog_ok(String descripcion,int unidades)
    {
        Bundle args =new Bundle();
        args.putString("descripcion",descripcion);
        args.putInt("cantidad",unidades);
        dialog_ok dialog_ok = new dialog_ok();
        dialog_ok.setTargetFragment(WelcomeFragment.this,1);
        dialog_ok.setCancelable(false);
        dialog_ok.setArguments(args);
        dialog_ok.show(getFragmentManager(),null);
    }
    private void dialog_qr()
    {
        dialog_qr dialog_qr = new dialog_qr();
        dialog_qr.setTargetFragment(WelcomeFragment.this, 1);
        dialog_qr.setCancelable(false);
        dialog_qr.show(getFragmentManager(),null);
    }
    private void dialog_error()
    {
        dialog_error dialog_error = new dialog_error();
        dialog_error.setTargetFragment(WelcomeFragment.this, 1);
        dialog_error.setCancelable(false);
        dialog_error.show(getFragmentManager(),null);
    }
    private void dialog_comprastock(String descripcion,String cantidad,String preciounitario,String codigo)
    {
        Bundle args =new Bundle();
        args.putString("descripcion",descripcion);
        args.putString("cantidad",cantidad);
        args.putString("preciounitario",preciounitario);
        args.putString("codigo",codigo);
        dialog_comprastock dialog_comprastock = new dialog_comprastock();
        dialog_comprastock.setTargetFragment(WelcomeFragment.this,1);
        dialog_comprastock.setCancelable(false);
        dialog_comprastock.setArguments(args);
        dialog_comprastock.show(getFragmentManager(),null);
    }
}
