package com.example.car_wash_cliente;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ApiInterface {
    @GET("register.php")
    Call<User> performRegistration(@Query("dni") String DNI, @Query("nombre") String Nombre, @Query("apellido") String Apellido , @Query("fecha_nac") String FechaNac, @Query("genero") String Sexo, @Query("modelo_vehiculo") String ModeloVehiculo, @Query("direccion_correo") String DireccionCorreo, @Query("clave") String Clave, @Query("manufacturer") String Manufacturer, @Query("model") String Model, @Query("version") int Version, @Query("versionRelease") String VRelease, @Query("token") String Token);
    @GET("login.php")
    Call<User> performUserLogin(@Query("dni") String DNI, @Query("clave") String Clave);
    @POST("fcm_insert.php")
    Call<User> SendToken(@Query("dni") String DNI, @Query("fcm_token") String FCMToken);
    @GET("variablesajuste.php")
    Call<User> VariablesAjuste(@Query("dni") String DNI);
    @GET("cargar_credito.php")
    Call<User> performChargeCredit(@Query("dni") String DNI, @Query("credito") String Credito, @Query("fecha") String Fecha, @Query("vendedor") String Vendedor);
    @GET("clientecomproproducto.php")
    Call<User> ClienteComproProducto(@Query("dni") String DNI,@Query("importe_compra") int ImporteCompra,@Query("fecha") String Fecha,@Query("unidades") int Unidades,@Query("codigo_producto") String CodigoProducto);
    @GET("buscarstockporcodigo.php")
    Call<List<catalogo>> BuscarStockCodigo(@Query("codigo") String Codigo);
    @GET("consumir_ficha.php")
    Call<User> performOperation(@Query("dni") String DNI, @Query("valor_ficha") String ValorFicha,@Query("fecha") String Fecha);
    @GET("consumir_ficha_vale.php")
    Call<User> ConsumirFichaVale(@Query("dni") String DNI,@Query("fecha") String Fecha);
    @GET("box_funcion.php")
    Call<User> activategpio(@Query("gpio") String GPIO);
}
