package com.example.car_wash_cliente;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import static com.example.car_wash_cliente.PrefConfig.NameStringXML;
import static com.example.car_wash_cliente.PrefConfig.UserIDXML;

public class MainActivity extends AppCompatActivity implements LoginFragment.OnLoginFormActivityListener, WelcomeFragment.OnLogoutListener {

    public static PrefConfig prefConfig;
    public static ApiInterface apiInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Login");
        /********************************************************************************/
        /*                       CHECK FOR UPDATES                                      */
        /********************************************************************************/

        /********************************************************************************/
        /*                      FIRECLOUD MESSAGES                                      */
        /********************************************************************************/

        /********************************************************************************/
        /*                      FIRECLOUD MESSAGES                                      */
        /********************************************************************************/
        prefConfig = new PrefConfig(this);
        apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        if(findViewById(R.id.fragment_container) != null)
        {
            if(savedInstanceState != null)
            {
                return;
            }
            if(prefConfig.ReadLoginStatus())
            {
                getSupportFragmentManager().beginTransaction().add(R.id.fragment_container,new WelcomeFragment()).commit();
            }
            else
            {
                getSupportFragmentManager().beginTransaction().add(R.id.fragment_container,new LoginFragment()).commit();
            }
        }
        //String token = prefConfig.Read(UserToken);
        //prefConfig.DisplayToast(token);
    }
    /********************************************************************************/
    /*                      REALIZA REGISTRO USUARIO                                */
    /********************************************************************************/
    @Override
    public void performRegister() {
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new RegistrationFragment()).addToBackStack(null).commit();
    }
    /********************************************************************************/
    /*                      REALIZA LOGIN USUARIO                                   */
    /********************************************************************************/
    @Override
    public void performLogin(String name)
    {
        prefConfig.Write(NameStringXML,name);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new WelcomeFragment()).commit();
    }
    /********************************************************************************/
    /*                      REALIZA LOGOUT USUARIO                                  */
    /********************************************************************************/
    @Override
    public void logoutperformed() {
        prefConfig.WriteLoginStatus(false);
        prefConfig.Write(NameStringXML,"User");
        prefConfig.Write(UserIDXML,"User");
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new LoginFragment()).commit();
    }

}
