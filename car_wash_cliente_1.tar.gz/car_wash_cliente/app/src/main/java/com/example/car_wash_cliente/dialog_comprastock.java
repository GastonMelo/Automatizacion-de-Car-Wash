package com.example.car_wash_cliente;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatDialogFragment;

import static android.content.ContentValues.TAG;

public class dialog_comprastock extends AppCompatDialogFragment {
    AlertDialog alertDialog;
    EditText descripciontxt,cantidadtxt,preciounitariotxt,codigotxt,unidadestxt;
    QRCompraStockListenner qrCompraStockListenner;

    public interface QRCompraStockListenner
    {
        void QRCompraAceptada(int valor,int unidades,String descripcionproducto);
    }
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.comprarproductostock, null);
        Button Cancelar = view.findViewById(R.id.cancelar);
        Button Aceptar = view.findViewById(R.id.aceptar);
        descripciontxt = view.findViewById(R.id.descripciontexto);
        cantidadtxt = view.findViewById(R.id.cantidadtexto);
        preciounitariotxt = view.findViewById(R.id.preciounitariotexto);
        codigotxt = view.findViewById(R.id.codigotexto);
        unidadestxt = view.findViewById(R.id.unidadestxt);
        Bundle args = getArguments();
        final String aux1 = args.getString("descripcion");
        descripciontxt.setText(aux1);
        final String aux2 = args.getString("cantidad");
        cantidadtxt.setText(aux2);
        final String aux3 = args.getString("preciounitario");
        preciounitariotxt.setText(aux3);
        final String aux4 = args.getString("codigo");
        codigotxt.setText(aux4);
        Aceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Integer.parseInt(aux2) != 0 && Integer.parseInt(aux2)>0)
                {
                    int precio = Integer.parseInt(preciounitariotxt.getText().toString());
                    int unidades = Integer.parseInt(unidadestxt.getText().toString());
                    int precio_total = precio*unidades;
                    qrCompraStockListenner.QRCompraAceptada(precio_total,unidades,aux1);
                }
                else
                {
                    MainActivity.prefConfig.DisplayToast("No hay stock del producto");
                }
                getDialog().dismiss();
            }
        });
        Cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getDialog().dismiss();
            }
        });
        builder.setView(view);
        alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        return alertDialog;
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            qrCompraStockListenner = (QRCompraStockListenner) getTargetFragment();
        }catch (ClassCastException e){
            Log.e(TAG, "ClassCastException: " + e.getMessage());
        }
    }
}
